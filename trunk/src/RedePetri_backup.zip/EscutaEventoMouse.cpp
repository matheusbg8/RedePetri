#include "EscutaEventoMouse.h"

EscutaEventoMouse::EscutaEventoMouse()
{
}

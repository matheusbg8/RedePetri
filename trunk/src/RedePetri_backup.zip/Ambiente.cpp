#include "Ambiente.h"


/**
 * @brief
 *  Registrar uma variavel siginifica dizer que uma variavel pertence
 * a um ambiente, no registro de uma variavel um vertice é criado
 * representando a novavariavel e um id e a definição do ambiente da
 * variavel é definida. O ambiente passa a conter a nova variavel
 * a morte do ambiente implica na morte de suas variaveis.
 *
 * @param varivavel
 * @return bool
 */
bool Ambiente::registraVariavel(VariavelAmbiente *varivavel)
{
    // Se pertence a um abiente diferente
    if(varivavel->m_ambiente != 0x0 && varivavel->m_ambiente != this)
    {
        cout << "Erro ao registrar variavel ao ambiente, ela pertence a outro ambiente" << endl;
        return false;
    }

    // Se ja esta no ambiente
    if(varivavel->m_ambiente == this && m_grafo.existeVertice(varivavel->m_id))
    {
        return true;
    }

    // Se ainda não existe em lugar algum
    int idNovaVariavel = m_grafo.novoVertice();

    // Verifica se conseguiu cria novo vertice
    if( idNovaVariavel < 0)
    {
        cout << "Erro ao registrar nova variavel, problema com o grafo" << endl;
        return false;
    }

    // Configura nova variavel
    varivavel->m_id = idNovaVariavel;
    varivavel->m_ambiente = this;

    // Verifica se é necessario alocar mais elementos
    if(idNovaVariavel >= m_variaveis.size() )
        m_variaveis.resize((idNovaVariavel+1)*2);

    // Armazena a variavel
    m_variaveis[idNovaVariavel] = varivavel;

    // Registrada :) Ok
    return true;
}

Ambiente::Ambiente(string nome):
    VariavelAmbiente(nome, string())
{
    // O ambiente de um ambiente e o proprio ambiente
    m_ambiente = this;
    m_id = m_grafo.novoVertice();
    m_variaveis.push_back(this);
}

Ambiente::~Ambiente()
{
    // Forca que as variaveis sejam deletadas
    // primeiro, se nao forcar, elas tentaram
    // se deletarem utilizando o grafo do ambiente
    // que não existira quando o ambiente
    // for destruido, como ambiente herda
    // VariavelAmbiente, o destrutor do ambinte
    // sempre é chamado antes do destrutor das
    // variaveis e um erro acontecera
    executandoDestrutor = true;
    for(unsigned i = 0 ; i < m_variaveis.size() ; i++)
    {
        if(m_variaveis[i] != this && m_variaveis[i] != 0x0)
            delete m_variaveis[i];
    }
    m_variaveis.clear();

    // Destroi as perguntas
    for(unsigned i = 0; i  < m_perguntas.size() ; i++)
    {
        delete m_perguntas[i];
    }
    m_perguntas.clear();
}


VariavelAmbiente *Ambiente::get(unsigned id)
{
    // Se nao existe o ID
    if(!m_grafo.existeVertice(id))
        return 0x0; // Retorna null

    return m_variaveis[id];
}

VariavelAmbiente *Ambiente::get(string nome)
{
    return VariavelAmbiente::get(nome);
}

/**
 * @brief
 *  Adiciona uma nova pergunta ao ambiente
 * @param novaPergunta
 * @return bool
 */
bool Ambiente::addPergunta(PergutaAmbiente *novaPergunta)
{
//    if(m_perguntas.find(novaPergunta->nome()) == m_perguntas.end())
//    {
//        novaPergunta->setAmbiente(this);
//        m_perguntas[novaPergunta->nome()] = novaPergunta;
//        return true;
//    }
//    return false;
}


/**
 * @brief
 *  Faz uma pergunta
 * @param nomePergunta - Nome da pergunta
 * @return bool - true se ela for verdade, false caso contrario.
 */
bool Ambiente::pergunta(string nomePergunta)
{
//    map<string, PergutaAmbiente*>::iterator i;
//    i = m_perguntas.find(nomePergunta);

//    // Se a pergunta não existe
//    if(i == m_perguntas.end())
//    {
//        return false;
//    }
//    // Se existe, faz pargunta, retorna resposta
//    return i->second->verdade();
}


/**
 * @brief
 *  Acessa uma pergunta
 * @param nomePergunta - Nome da pergunta que sera acessada
 * @return const PergutaAmbiente - Refrencia contante a pergunta, ou
 * 0x0 se ela não existir
 */
const PergutaAmbiente *Ambiente::getPergunta(string nomePergunta)
{
//    map<string, PergutaAmbiente*>::iterator i;
//    i = m_perguntas.find(nomePergunta);

//    // Se a pergunta não existe
//    if(i == m_perguntas.end())
//    {
//        return 0x0;
//    }

//    // Se existe
//    return i->second;
}

void Ambiente::imprimeVariaveis()
{
    list<ArestaGrafo*>::const_iterator la;
    VariavelAmbiente *de , *para;

    for(la = m_grafo.arestaBegin() ; la != m_grafo.arestaEnd() ; la++)
    {
        de = m_variaveis[(*la)->de()];
        para = m_variaveis[(*la)->para()];

        cout << "( " << de->nome() << " , " << de->valor() << " , " << de->m_id << " ) "
             << " --> "
             << "( " << para->nome() << " , " << para->valor() << " , " << para->m_id << ")"
             << endl;
    }
}

const Grafo *Ambiente::grafo() const
{
    return &m_grafo;
}


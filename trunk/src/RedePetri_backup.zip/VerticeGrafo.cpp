#include "VerticeGrafo.h"

VerticeGrafo::VerticeGrafo(unsigned id, Grafo *grafo)
{
    m_id = id;
    m_grafo = grafo;
}

unsigned VerticeGrafo::id() const
{
    return m_id;
}

Grafo *VerticeGrafo::grafo()
{
    return m_grafo;
}

const Grafo *VerticeGrafo::grafo() const
{
    return m_grafo;
}

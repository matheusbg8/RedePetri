#include "VariavelAmbiente.h"
#include "Ambiente.h"
#include <sstream>



string VariavelAmbiente::encontraNomeDisponivel(const string &nome)
{
    if(m_ambiente == 0x0)
        return nome;

    // Pega o numero de pais da variavel
    int numPais = m_ambiente->m_grafo.numPredecessores(m_id),
            i;

    VariavelAmbiente *pai = 0x0;
    VariavelAmbiente *varConflito = 0x0;
    string novoNome = nome;
    unsigned tentativa = 1;

    // Para cada pai, tenta entrar em um acordo do novo nome
    for( i = 0; i < numPais ; i++)
    {
        // Pega um pai
        pai = m_ambiente->get(m_ambiente->m_grafo.predecessor(m_id, i));

        // Verifica se pai aceita novo nome
        varConflito = pai->getDireto(novoNome);

        // Se não aceita
        if(varConflito != 0x0 && varConflito != this)
        {
            stringstream ss;
            ss << nome << '_' << tentativa;
            novoNome = ss.str();
            tentativa++;

            // Tenta acordo do novo nome com todos pais
            i = -1;
        }
    }
    return novoNome;
}

/**
 * @brief
 *  Ao registrar um mapeamento, uma entrada para o nome da
 * variavel no mapa da variavel pai é criado
 *
 * @param nome - Nome da variavel
 * @param id - Id da variavel
 * @return string - Nome realmente atribuido a variavel
 */
string VariavelAmbiente::registraMapeamento(const string &nome, unsigned id)
{
    unsigned tentativa =1; // Controle de tentativas
    string final = nome; // Nome final

    pair< map<string, unsigned>::iterator , bool >
     insercao; // Pair de insercao do map

    // Tenta Inserir o nome no mapa
    insercao = m_mapaVariaveis.
            insert( pair< const string &, unsigned> (final , id));

    // Equanto o nome ja existir para outro ID
    while(insercao.second == false && insercao.first->second != id)
    {
        // Tenta um novo nome
        stringstream ss;
        ss << nome << "_" << tentativa;
        final = ss.str();
        tentativa++;

        // Tenta inserir novo nome
        insercao = m_mapaVariaveis.
                insert( pair< const string &, unsigned> (final , id));
    }

    return final;
}

VariavelAmbiente *VariavelAmbiente::getDireto(const string &nomeVariavel)
{
    map<string , unsigned>::iterator lv = m_mapaVariaveis.find(nomeVariavel);

    //Tenta encontrar a variavel
    if( lv  == m_mapaVariaveis.end())
    {
        // Variavel não encontrada
        return 0x0;
    }

    unsigned idvariavelEncontrada = lv->second;

    return m_ambiente->get(idvariavelEncontrada);
}


/**
 * @brief
 *  Renomeia uma entrada do mapeamento da variavel
 * @param variavel - Variavel que tera mapeamento renomeado
 * @param novoNome - Novo nome
 * @return string - Novo nome renomeado, talvez modificado
 * para resolver conflito, ou "" se algum erro correr.
 */
string VariavelAmbiente::renomeiaVariavel(VariavelAmbiente* variavel, const string &novoNome)
{
    VariavelAmbiente *variavelMapeada = getDireto(variavel->nome());

    // Se a variavel não foi encontrada
    if(variavelMapeada == 0x0)
    {
        cout << "VariavelAmbiente:: Erro de mapeamento de variavel!!" << endl;
        return string();
    }

    // Se a variavel for diferente da mapeada
    if(variavel != variavelMapeada)
    {
        if(variavel == getDireto(novoNome))
            return novoNome; // Nao renomeia, ja esta correto

        cout << "VariavelAmbiente:: Erro de mapeamento de variavel!!" << endl;
        return string(); // Erro de mapeamento de variavel
    }

    // Apaga o nome do mapa
    m_mapaVariaveis.erase(variavel->nome());

    // Insere novo nome no mapa
    string nomeFinal =registraMapeamento(novoNome, variavel->m_id);

    return nomeFinal;
}


VariavelAmbiente::VariavelAmbiente(string nome, string valor )
{
    m_nome = nome;
    m_valor = valor;
    m_ambiente = 0x0;

    // Esta flag é utilizada para solucionar um problema no destrutor dessa classe
    executandoDestrutor = false;
}

/**
 * @brief
 *  Deleta a variavel de ambiente.
 */
VariavelAmbiente::~VariavelAmbiente()
{
    // Essa flag só pode ser alterada nesta parte do codigo
    // indica que a variavel esta sendo desalocada
    executandoDestrutor = true;

    // Se faz parte de um ambiente
    if(m_ambiente != 0x0 && m_ambiente != this)
    {
        // Se remove de todos pais
        int numPais = m_ambiente->m_grafo.numPredecessores(m_id),
                i;

        VariavelAmbiente *pai = 0x0;
        for( i = 0 ; i < numPais ; i++)
        {
            pai = m_ambiente->get(m_ambiente->m_grafo.predecessor(m_id, i));
            if(pai != 0x0)
            {
                pai->removeVariavel(m_nome);
            }
        }
        // Ao remover todos os pais
        // não existira nenhuma referencia para esta variavel
        // a ação padrao do ultimo pai que for removido
        // é de deletar o filho (eu), porem o filha ja
        // esta sendo destruido aqui, por isso foi necessario
        // a flag executandoDestrutor para evitar um doublefree

        // O mesmo problema ocorreu no desenvolvimento dos desenhos
    }

    // Deleta todas as variaveis de ambiente que estou mapeando
    map<string , unsigned>::iterator i;
    for( i = m_mapaVariaveis.begin() ; i != m_mapaVariaveis.end() ; i++)
    {
        removeVariavel(i->first);
    }
    m_mapaVariaveis.clear();

    // Se eu não sou o ambiente
    if(m_ambiente != this)
    {
        // Se remove do ambiente
        m_ambiente->m_grafo.deletaVertice(m_id);
        m_ambiente->m_variaveis[m_id] = 0x0;
    }// Se eu for o ambiente, m_grafo e m_variaveis nao existem mais

    m_ambiente = 0x0;
}

VariavelAmbiente *VariavelAmbiente::get(string nome)
{
    int ini = 0, fim;
    VariavelAmbiente *varAtual = this;

    fim = nome.find('.' , ini+1);
    while(fim != -1)
    {
        varAtual = varAtual->getDireto(nome.substr(ini, fim - ini));

        if(varAtual == 0x0)
            return varAtual;

        ini = fim+1;
        fim = nome.find('.' , ini);
    }

    return varAtual->getDireto(nome.substr(ini));
}

bool VariavelAmbiente::possuiAmbiente() const
{
    return m_ambiente != 0x0;
}


/**
 * @brief
 *  Ao adicionar uma variavel, uma referencia de pai-filho
 * é estabelecida entre as veariaveis, uma entrada no
 * mapeamento de variaveis do pai é criado, um vertice
 * representando a nova variavel e uma aresta entre o
 * vertice pai->filho é criado no ambiente, o ambiente
 * passa a conter a variavel.
 *
 * @param novaVariavel
 * @return bool
 */
bool VariavelAmbiente::addVariavel(VariavelAmbiente *novaVariavel)
{
    // Se a variavel é valida
    if(novaVariavel == 0x0)
    {
        cout << "VariavelAmbiente: Adicionando variavel invalida" << endl;
        return false;
    }

    // Registra variavel no ambiente,
    // se ela ja esta registrada nao tem problema
    if(!m_ambiente->registraVariavel(novaVariavel)) // Aqui um id pode ser gerado para variavel
    {
        // Se não consegiu registra, tem algo errado
        // com essa variavel, ela nao pode ser utilizada
        return false;
    }

    // Estabelece relacao hierarquica utilizando grafo
    int idAresta = m_ambiente->m_grafo.novaAresta(m_id , novaVariavel->m_id, 1.f);
    if(idAresta < 0)
    {
        cout << "VariavelAmbiente::Erro ao estabelecer hierarquia" << endl;
        return false;
    }

    // Procura nome disponivel entre todos os pais
    // ja considerando que eu sou um pai (por causa da aresta ja adicionada)
    string novoNome = novaVariavel->encontraNomeDisponivel(novaVariavel->nome());

    // Adiciona nova variavel ao meu mapeamento
    // Se mesmo assim o meu mapeamento alterar o nome
    if(novoNome != registraMapeamento(novoNome, novaVariavel->m_id))
    {
        // Um problema aconteceu ao encontrarNomeDisponivel
        // nao foi considerado o meu mapeamento na busca
        cout << "Erro ao adicionar novavarivel, comflito de nomes nao resolvido" << endl;
    }

    // O nome tem que ser setado apenas apos o mapemaneto
    // da nova variavel, setNome vai renomear todos
    // mapeamentos de todos pais, o mapeamento detecta
    // que a variavel ja foi renomeada neste pai
    novaVariavel->setNome(novoNome);


    return true;
}

bool VariavelAmbiente::addVariavel(string nome, string valor)
{
    int ini = 0, fim;
    VariavelAmbiente *varAtual = this;
    VariavelAmbiente *varAterior = this;
    string subStr;

    fim = nome.find('.' , ini+1);
    while(fim != -1)
    {
        subStr = nome.substr(ini, fim - ini);
        varAtual = varAtual->getDireto(subStr);

        if(varAtual == 0x0)
        {
            varAtual = new VariavelAmbiente(subStr , string());
            varAterior->addVariavel(varAtual);
        }

        varAterior = varAtual;

        ini = fim+1;
        fim = nome.find('.' , ini);
    }

    subStr = nome.substr(ini);
    varAtual = varAtual->getDireto(subStr);

    if(varAtual == 0x0)
    {
        varAtual = new VariavelAmbiente(subStr , valor);
        varAterior->addVariavel(varAtual);
    }

    return true;
}

bool VariavelAmbiente::removeVariavel(VariavelAmbiente *variavel)
{
    // Poderia remover pelo ID da variavel tbm (seria mais eficiente)
    // Se for implementado, alterar o destrutor para remover pro id
    // chamando second do iterator map
    return removeVariavel(variavel->nome());
}

bool VariavelAmbiente::removeVariavel(const string &nomeVariavel)
{
    VariavelAmbiente *variavel = getDireto(nomeVariavel);

    if(variavel == 0x0)
        return true;

    // Remove do mapa de nomes
    m_mapaVariaveis.erase(nomeVariavel);

    // Remove relacao hirarquica
    m_ambiente->m_grafo.deletaAresta(m_id , variavel->m_id);
    // Esse tipo de deletacao nao tem complexidade constante no grafo de lista
    // como a que deleta por ID

    // Verifica se ainda possui alguma referencia
    if(m_ambiente->m_grafo.numPredecessores(variavel->m_id) == 0)
    {
        // Se não tem, e a variavel não estiver sendo destruida
        if(!variavel->executandoDestrutor && m_ambiente != variavel)
        {
            // Deleta variavel
            delete variavel;
        }

    }
    return true;
}

const string &VariavelAmbiente::nome() const
{
    return m_nome;
}

const string &VariavelAmbiente::valor() const
{
    return m_valor;
}

void VariavelAmbiente::setValor(string valor)
{
    m_valor = valor;
}

const string & VariavelAmbiente::setNome(string nome)
{
    // Se nao tem ambiente
    if(m_ambiente == 0x0)
    {   // Variavel é solta, nao depende de ninguem
        m_nome = nome;
        return m_nome;
    }

    // Verifica se o novo nome pode ser definido
    // se existir algum conflito com algum pai
    // o nome é modificado para resolver os conflitos
    string novoNome = encontraNomeDisponivel(nome);


    // Pega o numero de pais da variavel
    int numPais = m_ambiente->m_grafo.numPredecessores(m_id),
            i;
    VariavelAmbiente * pai = 0x0;

    // Avisa renomecao para todos pais
    for( i = 0; i < numPais ;i++)
    {
        pai = m_ambiente->get(m_ambiente->m_grafo.predecessor(m_id, i));

        // A renomecao e certa, porque o nome ja foi
        // testado em todos os pais e esta disponivel
        pai->renomeiaVariavel(this, novoNome);
    }

    // Finalmente define o novo nome
    m_nome = novoNome;
    return m_nome;
}

unsigned VariavelAmbiente::id() const
{
    return m_id;
}

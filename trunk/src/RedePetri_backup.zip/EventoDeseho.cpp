#include "EventoDeseho.h"

EventoDeseho::EventoDeseho()
{
}

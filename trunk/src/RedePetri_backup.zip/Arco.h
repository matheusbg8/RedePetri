#ifndef ARCO_H
#define ARCO_H

#include "DComponentePetri.h"

class RedePetri;

class Arco : public DComponentePetri
{
private:
    int m_custo;
    RedePetri *m_redePetri;
public:
    Arco(RedePetri *redePetri);

    bool setLigacao(DComponentePetri *de, DComponentePetri *para);
    bool setCusto(int val);
};

#endif // ARCO_H

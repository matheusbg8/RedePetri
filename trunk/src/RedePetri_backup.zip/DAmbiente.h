#ifndef DAMBIENTE_H
#define DAMBIENTE_H

#include "Container.h"
#include "DVariavelAmbiente.h"

class CAmbiente;

class DAmbiente :public QObject, public Container
{
    Q_OBJECT

private:

    QMenu *mnuFundo;

    QAction *actNovaVariavel;
    QAction *actNovaPergunta;
    QAction *actCriaReferencia;
    QAction *actDeleta;

    void criaAcoes();
    void criaMenus();

protected:
    vector<DVariavelAmbiente*> m_variaveis;
    CAmbiente *m_controleAmbiente;

    void mousePrecionado(MouseEvento *novoMouseEvento);

    void adicionaVariavelRaiz();

private slots:
    void novaVariavel();
    void novaPergunta();
    void criaReferencia();
    void deleta();

public:
    DAmbiente();
    ~DAmbiente();

    CAmbiente* controle();

    void setControleAmbiente(CAmbiente *controle);

    // Visualização das variaveis
    bool addVariavel(unsigned idVarPai, const VariavelAmbiente *novaVariavel);
    bool removeVariavel(unsigned varId);

    void apagaTudo();

    bool setNome(unsigned idVar, QString nome);
    void setNome( QString nome);

    bool setValor(unsigned idVar , QString valor);

};

#endif // DAMBIENTE_H

#ifndef DTRANSICAO_H
#define DTRANSICAO_H

#include "Retangulo.h"
#include "RedePetri.h"
#include "DComponentePetri.h"

class DTransicao :public QObject,  public Retangulo, public DComponentePetri
{
    Q_OBJECT
public:
    DTransicao();
    ~DTransicao();

    void *getSuper();
    virtual void desenha();

    void setNome(QString m_nome);

    // Interface ComponentePetri
    bool setRede( RedePetri* redePetri);
    RedePetri * getRedePetri();
    unsigned getIDLocal();
    bool ehTransicao();
    bool ehLugar();
    bool ehArco();
    string &informacao();

protected:

    unsigned m_id; /**< Indice da Transição na rede petri  */
    RedePetri *m_redePetri;  /**< Rede Petri que a transição esta */

private:
    void inicializaDTransicao();
    void mousePrecionado(MouseEvento *novoMouseEvento);

    QMenu *mnu;
    QAction *actDeleta;
    QAction *actExecuta;
    QAction *actNovoArco;

    void criaAcoes();
    void criaMenus();

public slots:
    void deleteta();
    void executa();
    void novoArco();

};

#endif // DTRANSICAO_H

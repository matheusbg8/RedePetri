#ifndef TESTEDESENHOCOMPOSTO_H
#define TESTEDESENHOCOMPOSTO_H

#include "DesenhoComposto.h"
#include "CirculoBasico.h"
class TesteDesenhoComposto: public DesenhoComposto
{
private:
    Circulo *circCimaDireita;
    Circulo *circCimaEsquerda;
    Circulo *circBaixoDireita;
    Circulo *circBaixoEsquerda;
public:
    TesteDesenhoComposto();

    void mousePrecionadoComposto(Desenho *desenho, MouseEvento *mouseEvento);
    void mouseSoltoComposto(Desenho *desenho, MouseEvento *mouseEvento);
    void mouseMovendoComposto(Desenho *desenho, MouseEvento *mouseEvento);
};

#endif // TESTEDESENHOCOMPOSTO_H

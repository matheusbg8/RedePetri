#ifndef VISUALIZADORPROPRIEDADES_H
#define VISUALIZADORPROPRIEDADES_H

#include <QTreeWidget>
#include "DLugar.h"
#include "DTransicao.h"
#include "DArco.h"
#include "DRedePetri.h"


class VisualizadorPropriedades : public QTreeWidget
{
    Q_OBJECT
public:
    explicit VisualizadorPropriedades(QWidget *parent = 0);
    void visualizaDesenho(Desenho *desenho);

private:
    void inseriDesenho(QTreeWidgetItem *raiz, Desenho *desenho);
    bool alteracaoDesenho(QTreeWidgetItem *itemAlterado, int coluna);

    void inseriLugar(QTreeWidgetItem *raiz,DLugar *lugar);
    bool alteracaoLugar(QTreeWidgetItem *itemAlterado, int coluna);

    void inseriTransicao(QTreeWidgetItem *raiz,DTransicao *transicao);
    bool alteracaoTransicao(QTreeWidgetItem *itemAlterado, int coluna);

    void inseriArco(QTreeWidgetItem *raiz, DArco *arco);
    bool alteracaoArco(QTreeWidgetItem *itemAlterado, int coluna);

    void inseriRedePetri(QTreeWidgetItem *raiz, DRedePetri *redePetri);
    bool alteracaoRedePetri(QTreeWidgetItem *itemAlterado, int coluna);

    bool contem(QTreeWidgetItem *item, QString texto);


    Desenho *desenhoVisualizado;

signals:
    
public slots:
    void alteracaoItem(QTreeWidgetItem *itemAlterado, int coluna);
    void duploClique(QTreeWidgetItem *itemClicado, int coluna);

};

#endif // VISUALIZADORPROPRIEDADES_H

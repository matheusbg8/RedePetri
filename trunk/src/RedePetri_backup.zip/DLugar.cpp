#include "DLugar.h"
#include "iostream"
#include "RedePetri.h"
#include "DRedePetri.h"
#include "Container.h"

using namespace std;

void DLugar::iniciaDLugar()
{
    m_tipoDesenho = TD_LUGAR;
    m_redePetri = 0x0;

    setCorFundo(Cor::amarelo);
    Circulo::setNome(QString("Lugar %1").arg(id()));
    criaAcoes();
    criaMenus();
}


DLugar::DLugar():Circulo(15, rPonto(20,20), 0x0)
{
    iniciaDLugar();
}

DLugar::~DLugar()
{
    if(m_redePetri != 0x0)
    {
        // Exclui o lugar do modelo de dados
        m_redePetri->Exclui_Lugar(m_id);
    }
    m_redePetri = 0x0;
    // O tratamento de desalocamento do desenho é feito
    // no destrutor do desenho.
    // as escutas são avisadas que esse desenho foi destruido
}


void *DLugar::getSuper()
{
    return this;
}

bool DLugar::setNumeroFichas(int numFichas)
{
    if(m_redePetri != 0x0)
    {
        m_redePetri->Inserir_Fichas(m_id, numFichas);
        return true;
    }
    return false;
}

int DLugar::getNumFichas()
{
    if(m_redePetri != 0x0)
    {
        return m_redePetri->Numero_Fichas(m_id);
    }
    return 0;
}


/**
 * @brief
 *  Retorna uma cópia da informação da ficha
 * @param IDFicha - ID da ficha
 * @return string - copia da informação da ficha
 */
string DLugar::getInfoFicha(unsigned IDFicha)
{
    if(m_redePetri != 0x0)
    {
        if(IDFicha < getNumFichas())
        {
            return m_redePetri->Informacao_Ficha(m_id,IDFicha);
        }else
        {
            cout << "Erro acessando info ficha com ID invalido" << endl;
        }
        cout << "Erro ao acessar info ficha, lugar sem RedePetri associado" << endl;
    }
    return "";
}


/**
 * @brief
 *  Define uma nova informação para a ficha
 * @param IDFicha - ID da ficha que recebera nova informação
 * @param info - Informação que sera atribuida
 * @return bool - True se foi atribuido, false se
 * algum erro ocorreu.
 */
bool DLugar::setInfoFicha(unsigned IDFicha, string info)
{
    if(IDFicha < getNumFichas())
    {
        m_redePetri->Define_Informacao_Ficha(m_id, IDFicha, info);
//        m_redePetri->Informacao_Ficha(m_id, IDFicha) = info;
        return true;
    }
    cout << "Erro ao atribuir info a ficha, ID inválido" << endl;

    return false;
}

void DLugar::desenha()
{
    Circulo::desenha();
    desenhaTexto(QString("%1").arg(getNumFichas()), rPonto(10.0f,10.0f), QFont("Times",15, QFont::Bold));

}

void DLugar::setNome(QString nome)
{
 //   Circulo::setNome(QString("p%1 ").arg(m_id) + nome);
    Circulo::setNome(nome);
}

/**
 * @brief
 *  Define o modelo de dados da RedePetri para o lugar,
 * quando essa rede for definida, um novo lugar sera criado
 * nela.
 *  Se a rede que estiver sendo definida for 0x0, fara com
 * que a referencia ao modelo da antiga Rede de Petri sera
 * desfeita.
 *  Se o lugar já tiver referencia a um modelo de Rede
 * Petri, o novo modelo não sera definido, um mensagem de
 * erro sera impressa e false sera retornado.
 * @param redePetri - Modelo de dados da Rede Petri que
 * sera definido.
 * @return bool - true se o modelo foi definido, false
 * caso contrario.
 * @todo - Pergunta: Nesse metodo, quando um modelo
 * for excluido, o DLugar deve remover sua representação
 * de dentro do modelo? Provavelmente sim, por enquanto
 * apenas o destrutor da DRedePetri apaga o modelo dando
 * setRede(0x0), esta tarefa deve ser implementada.
 */
bool DLugar::setRede(RedePetri *redePetri)
{
    // Se a rede de dados é valida
    if(redePetri != 0x0)
    {
        // Se ja tiver referencia a um modelo
        if(m_redePetri != 0x0)
        {
            QMessageBox msg;
            msg.setText("Erro, nao pode existir um elemento representando duas redes de petri");
            msg.setInformativeText("Foi atribuido uma nova rede de petri a um elemento que pertencia a uma outra rede de petri, a nova rede nao foi atribuida a esse elemento.");
            msg.setIcon(QMessageBox::Critical);
            msg.exec();
            return false;
        }

        // Define o modelo
        m_redePetri = redePetri;
        m_id = m_redePetri->Novo_Lugar();
        Circulo::setNome(QString("p%1").arg(m_id));

        return true;
    }

    m_redePetri = 0x0;
}

RedePetri *DLugar::getRedePetri()
{
    return m_redePetri;
}

unsigned DLugar::getIDLocal()
{
    return m_id;
}

bool DLugar::ehTransicao()
{
    return false;
}

bool DLugar::ehLugar()
{
    return true;
}

bool DLugar::ehArco()
{
    return false;
}


void DLugar::novoArco()
{
    DArco *d = new DArco;
    m_pai->novoDesenho(d);
    d->setLigacaoIni(this);
    d->comecaRastriamento();
}

void DLugar::deleta()
{
    delete this;
}

void DLugar::adicionaFicha()
{
    setNumeroFichas(getNumFichas() + 1);
}

void DLugar::removeFicha()
{
    setNumeroFichas(getNumFichas() - 1);
}


/**
 * @brief
 *  Inicializa as ações utilizadas no menu do PopUp Menu,
 * aqui as ações sera inicializadas conectando os sinais em
 * seus devidos slots.
 * Esse metodo só é chamado uma vez durante a construção do objeto.
 */
void DLugar::criaAcoes()
{
    novoArcoAct = new QAction("Novo Arco" ,this);
    QObject::connect(novoArcoAct, SIGNAL(triggered()), this, SLOT(novoArco()));
    deletaAct = new QAction("Deleta" ,this);
    QObject::connect(deletaAct, SIGNAL(triggered()), this, SLOT(deleta()));
    actADDFicha = new QAction("Adiciona Ficha" ,this);
    QObject::connect(actADDFicha, SIGNAL(triggered()), this, SLOT(adicionaFicha()));
    actRMVFicha = new QAction("Remove Ficha" ,this);
    QObject::connect(actRMVFicha, SIGNAL(triggered()), this, SLOT(removeFicha()));
    actNovoArco = new QAction("Novo Arco" ,this);
    QObject::connect(actNovoArco, SIGNAL(triggered()), this, SLOT(novoArco()));
}

/**
 * @brief
 * Inicializa os menus utilizado no POPUP menu dos lugar
 * Esse metodo só é chamado uma vez durante a construção do objeto.
 */
void DLugar::criaMenus()
{
   /**
     @todo - Verificar qual efeito provocado
     se for passado 0x0 como pai do QMenu, pois
     nem sempre o desenho vai ter o desenho mestre
     definido durante a construção do objeto,
     (na verdade nunva vai ter o desenho mestre definido,
     so depois que o pai já foi definido)
      em DTransicao::criaMenus() tbm ocorre o mesmo problema.
   **/
    mnu = new QMenu(widget());
    mnu->addAction(novoArcoAct);
    mnu->addAction(actADDFicha);
    mnu->addAction(actRMVFicha);
    mnu->addAction(deletaAct);
}

void DLugar::mousePrecionado(MouseEvento *e)
{
    if(e->botao() == BOTAO_DIREITO)
    {
        mnu->exec(e->posicaoJanela());
        return;
    }
    Circulo::mousePrecionado(e);
}

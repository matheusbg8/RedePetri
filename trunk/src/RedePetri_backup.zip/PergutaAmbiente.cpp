#include "PergutaAmbiente.h"

void PergutaAmbiente::setAmbiente(Ambiente *ambiente)
{
    m_ambiente = ambiente;
}


PergutaAmbiente::PergutaAmbiente(string nome,string variavel, string valor)
{
    m_ambiente = 0x0;
    m_nome = nome;
    m_variavel = variavel;
    m_valor = valor;
}


/**
 * @brief
 *  Retorna true se a pergunta for verdade, false caso contrario
 * @return bool
 */
bool PergutaAmbiente::verdade()
{
//    // Se estou relacionado com um ambiente
//    if(m_ambiente == 0x0)
//        return false;

//    // Pergunto pela variavel para o ambiente
//    const VariavelAmbiente *variavel = m_ambiente->get(m_variavel);

//    // Se a variavel existe e se ela satisfaz minha condição
//    if(variavel != 0x0 && variavel->valor() == m_valor)
//    {
//        return true;
//    }
//    return false;
}


/**
 * @brief
 *  Retorna o nome da pergunta
 * @return const string
 */
const string &PergutaAmbiente::nome()
{
    return m_nome;
}


/**
 * @brief
 *  Retorna a variavel que esta sendo condicinada pela pergunta
 * @return const string
 */
const string &PergutaAmbiente::variavel()
{
    return m_variavel;
}


/**
 * @brief
 *  Retorna o valor da variavel condicinada para validar essa pergunta
 * @return const string
 */
const string &PergutaAmbiente::valor()
{
    return m_valor;
}


/**
 * @brief
 *  Retorna o ambiente ao qual a pergunta esta relacionada
 * @return Ambiente
 */
Ambiente *PergutaAmbiente::ambiente()
{
    return m_ambiente;
}

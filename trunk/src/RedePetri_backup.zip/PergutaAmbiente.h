#ifndef PERGUTAAMBIENTE_H
#define PERGUTAAMBIENTE_H

class Ambiente;

#include<string>
using namespace std;

class PergutaAmbiente
{
protected:
    string m_nome;
    string m_variavel;
    string m_valor;
    Ambiente *m_ambiente;

    void setAmbiente(Ambiente *ambiente);

public:
    PergutaAmbiente(string nome, string variavel, string valor);
    bool verdade();

    const string & nome();

    const string& variavel();
    const string& valor();

    Ambiente *ambiente();

    friend class Ambiente;
};

#include "Ambiente.h"


#endif // PERGUTAAMBIENTE_H

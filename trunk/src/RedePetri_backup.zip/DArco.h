#ifndef DARCO_H
#define DARCO_H

#include "Seta.h"
#include "DComponentePetri.h"
#include "RedePetri.h"

/**
 * @brief
 *  DArco representa representa a interface gráfica de um
 * unico arco de uma rede de petri, geralmente instanciado
 * dentro de uma DRedePetri, a classe DArco possui um referencia
 * para o modelo de dados da Rede Petri.
 *  A classe Darco herdando as propriedades e o comportamento
 * de uma seta, os metodos aceitaLigacaoIni(Desenho *desenho)
 * e ligacaoFim(Desenho *desenho) são chamados sempre quando
 * existir uma tentativa de estabelecer uma ligação com algum
 * outro desenho, esses metodos decidem se a ligação ocorrera
 * ou não, dependendendo do seu retorno, se for true, a ligação
 * sera estabelecida, caso contrario a ligação sera ignorada.
 *
 */
class DArco :public QObject, public Seta, public DComponentePetri
{
    Q_OBJECT
public:

    DArco();
    ~DArco();

    void * getSuper();

    void setCusto(int custo);
    int getCusto();

    DComponentePetri *getOrigem();
    DComponentePetri *getDestino();

    void desenha();

// Interface ComponentePetri
    bool setRede(RedePetri *redePetri);

    RedePetri * getRedePetri();

    unsigned getIDLocal();

    bool ehTransicao();

    bool ehLugar();

    bool ehArco();

protected:

    RedePetri *m_redePetri; // Rede Petri no qual esta esse Arco
    unsigned m_id; // ID desse Arco na rede petri
    int m_custo;

    // Sobrescrita dos metodos virtuais da seta
    bool aceitaLigacaoIni(Desenho *desenho);
    bool aceitaLigacaoFim(Desenho *desenho);

private:
    void inicializaDArco();

    DComponentePetri * pegaComponente(Desenho *desenho);
    void removeComponenteIni();
    void removeComponenteFim();

    void atualizaCustoEmModDados();

 // Menus do Qt
    QMenu *mnu;
    QAction *actDeleta;

    void mousePrecionado(MouseEvento *novoMouseEvento);

    DComponentePetri *m_cmpOrigem;
    DComponentePetri *m_cmpDestino;


    void criaAcoes();
    void criaMenus();

public slots:
    void deleta();

};

#endif // DARCO_H

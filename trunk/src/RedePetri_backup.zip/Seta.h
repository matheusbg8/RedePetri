#ifndef SETA_H
#define SETA_H

#include "Segmento.h"
#include "Triangulo.h"
#include "CirculoBasico.h"
#include "DesenhoComposto.h"

/**
 * @brief
 *   Esta classe representa uma seta, ela pode ser utilizada para ligar
 * dois desenhos com os metodos setLigacaoIni(Desenho *desenho) e
 * void setLigacaoFim(Desenho *desenho). O comportamento da seta
 * ao ligarse com um desenho é determinado pelos metodos virtuais
 * ligacaoIni(Desenho* desenho) e ligacaoFim(Desenho* desenho),
 * toda vez que uma ponta da seta é arrasta para cima de um desenho
 * esses metodos são chamados, por padrão eles simplesmente aceitão
 * a ligação com o desenho.
 */
class Seta : public DesenhoComposto
{
private:
    void inicializaSeta();

protected:
    Segmento *seg;
    Triangulo *triangulo;

    QString m_nomeSeta;

    Circulo *inicio;
    Circulo *fim;

    float m_comprimentoPonta;
    float m_aberturaPonta;

    Desenho *m_ligFim;
    Desenho *m_ligIni;

    bool m_rastriandoMouse;

    virtual void eventoAlteracaoPosicao(Desenho *desenho);
    virtual void eventoAlteracaoAltura(Desenho *desenho);
    virtual void eventoAlteracaoLargura(Desenho *desenho);

    virtual void eventoDeletando(Desenho *desenho);

    virtual bool aceitaLigacaoIni(Desenho* desenho);
    virtual bool aceitaLigacaoFim(Desenho* desenho);


    void desenhaNome();

public:
    Seta(Container *m_pai = 0x0);

    void defineSeta(rPonto p1, rPonto p2);
    void desenha();

    void novoDesenho(Desenho *d, bool avisaFilho);

    void mousePrecionadoComposto(Desenho *desenho, MouseEvento *novoMouseEvento);
    void mouseSoltoComposto(Desenho *desenho, MouseEvento *novoMouseEvento);
    void mouseMovendoComposto(Desenho *desenho, MouseEvento *mouseEvento);

    void setLigacaoIni(Desenho *desenho);
    void setLigacaoFim(Desenho *desenho);

    void setNomeSeta(QString nome);

    Desenho* getLigacaoIni();
    Desenho* getLigacaoFim();

    void *getSuper();

    void setSelecionado(bool m_selecionado);

    void comecaRastriamento();
};

#endif // SETA_H






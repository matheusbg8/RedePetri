#ifndef EVENTODESEHO_H
#define EVENTODESEHO_H

class EventoDeseho
{
protected:
//    bool
public:
    EventoDeseho();

//    bool estaEscutando(Desenho *desenho);
//    void novaEscuta(Desenho *d);
//    void removeEscuta(Desenho *d);
};

#endif // EVENTODESEHO_H

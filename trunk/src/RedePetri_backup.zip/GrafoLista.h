#ifndef GRAFOLISTA_H
#define GRAFOLISTA_H

#include "Grafo.h"
#include "GerenciadorElementos.h"
#include <vector>

using namespace std;

class GrafoLista : public Grafo
{
protected:
    // Armazena arestas
    GerenciadorElementos <ArestaGrafo*> m_arestas;

    // Armazena vertices
    GerenciadorElementos <VerticeGrafo*> m_vertices;

    // Armazena a relação entre os vertices e as arestas
    //                   destino     id da aresta
    vector< vector< pair< unsigned , unsigned > > > m_g;
    vector< vector< pair< unsigned , unsigned > > > m_invG;

    // Indexacao das arestas nas relacoes (cada pair indexa 1 aresta nas duas lista)
    //          i-esimo g  ,  i-esimo invG
//    vector< pair< unsigned , unsigned > > m_indAresta; nao deu certo porque os indices das listas mudam ao deletar as arestas

    int aresta(unsigned deIdVertice, unsigned paraIdVertice) const;

public:
    GrafoLista();
    virtual ~GrafoLista();

    Grafo * novoGrafo() const;

    unsigned novoVertice();

    void criaVertices(unsigned numVertices);

    int novaAresta(unsigned deIdVertice, unsigned paraIdVertice, float custo);

    bool deletaVertice(unsigned idVertice);

    bool deletaAresta(unsigned idAresta);

    bool deletaAresta(unsigned de, unsigned para);

    bool setCustoAresta(unsigned idAresta, float custo);

    unsigned idMaiorVertice() const;

    unsigned idMaiorAresta() const;

    unsigned idProximoVertice() const;

    unsigned idProximaAresta() const;

    bool existeVertice(unsigned idVertice) const;

    bool existeAresta(unsigned idAresta) const;

    bool existeAresta(unsigned de, unsigned para) const;

    unsigned numVertices() const;

    unsigned numArestas() const;

    int numPredecessores(unsigned idVertice) const;

    int predecessor(unsigned idVertice, unsigned i) const;

    float custoPredecessor(unsigned idVertice, unsigned i) const;

    int idArestaPredecessor(unsigned idVertice, unsigned i) const;

    int numSucessores(unsigned idVertice) const;

    int sucessor(unsigned idVertice, unsigned i) const;

    float custoSucessor(unsigned idVertice, unsigned i) const;

    int idArestaSucessor(unsigned idVertice, unsigned i) const;

    list<VerticeGrafo*>::const_iterator verticeBegin() const;
    list<VerticeGrafo*>::const_iterator verticeEnd() const;

    list<ArestaGrafo*>::const_iterator arestaBegin() const;
    list<ArestaGrafo*>::const_iterator arestaEnd() const;

    const VerticeGrafo* vertice(unsigned idVertice) const;
    const ArestaGrafo* aresta(unsigned idAresta) const;

};

#endif // GRAFOLISTA_H

#include "GerenciadorElementos.h"

template<typename Tipo>
GerenciadorElementos<Tipo>::GerenciadorElementos()
{
    m_numElementos = 0;
}

template<typename Tipo>
int GerenciadorElementos<Tipo>::proximoID() const
{
    if(m_proximos.empty())
    {
        return m_indElemento.size();
    }
    return m_proximos.top();
}

template<typename Tipo>
int GerenciadorElementos<Tipo>::adicionaElemento(const Tipo &valor)
{
    m_numElementos++;

    m_elementos.push_back(valor);
    iterator ind = --m_elementos.end();

    // Se existe buracos nos indices
    if(!m_proximos.empty())
    {
        int t = m_proximos.top();
        m_proximos.pop();

        m_indElemento[t] = ind;
        m_habilitado[t] = true;

        return t;
    }// else

    m_indElemento.push_back(ind);
    m_habilitado.push_back(true);

    return m_indElemento.size()-1;
}

template<typename Tipo>
void GerenciadorElementos<Tipo>::removeElemento(unsigned ID)
{
    if(ID < m_indElemento.size() && m_habilitado[ID])
    {
        m_proximos.push(ID);

        m_elementos.erase(m_indElemento[ID]);
        m_habilitado[ID] = false;

        m_numElementos--;
        return;
    }
    cout << "Erro ao excluir elemento, elemento inxistente, ou indice invpalido" << endl;
}

template<typename Tipo>
/**
 * @brief
 *  Apaga todos os elementos armazendados
 */
void GerenciadorElementos<Tipo>::apagaTudo()
{
    m_indElemento.clear();
    m_habilitado.clear();
    m_elementos.clear();

    m_numElementos =0;
    while(!m_proximos.empty())
        m_proximos.pop();
}


template<typename Tipo>
/**
 * @brief
 *  Retorna o numero de elementos armazenado
 * @return int - Número de elementos armazenado
 */
int GerenciadorElementos<Tipo>::tamanho() const
{
    return m_numElementos;
}


template<typename Tipo>
/**
 * @brief
 *  Retorna o maior indice dos elementos armazenados.
 * @return int
 */
int GerenciadorElementos<Tipo>::maiorIndice() const
{
    return m_indElemento.size()-1;
}

template<typename Tipo>
Tipo & GerenciadorElementos<Tipo>::operator [](int id)
{
    if(m_habilitado[id])
    {
        return *(m_indElemento[id]);
    }
    cout << "Erro, acesso a elemento com indice inválido!" << endl;

    return *(m_indElemento[0]); // O certo seria lançar uma execao
}

template<typename Tipo>
const Tipo & GerenciadorElementos<Tipo>::operator [](int id) const
{
    if(m_habilitado[id])
    {
        return *(m_indElemento[id]);
    }
    cout << "Erro, acesso a elemento com indice inválido!" << endl;

    return *(m_indElemento[0]); // O certo seria lançar uma execao
}




template<typename Tipo>
bool GerenciadorElementos<Tipo>::existeElemento(unsigned id) const
{
    if(id < m_indElemento.size() && m_habilitado[id])
    {
        return true;
    }
    return false;
}

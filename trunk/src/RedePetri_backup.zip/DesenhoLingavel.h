#ifndef DESENHOLINGAVEL_H
#define DESENHOLINGAVEL_H

#include "Desenho.h"

class DesenhoLingavel
{
public:

    DesenhoLingavel();
};

#endif // DESENHOLINGAVEL_H

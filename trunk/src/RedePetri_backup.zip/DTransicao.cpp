#include "DTransicao.h"

#include "DRedePetri.h"

void DTransicao::inicializaDTransicao()
{
    Retangulo::setNome(QString("Transicao %1").arg(id()));
    m_tipoDesenho = TD_TRANSICAO;
    m_redePetri = 0x0;

    setCorFundo(Cor::verde);

    criaAcoes();
    criaMenus();
}

void DTransicao::mousePrecionado(MouseEvento *novoMouseEvento)
{
    if(novoMouseEvento->botao() == BOTAO_DIREITO)
    {
        mnu->exec(novoMouseEvento->posicaoJanela());
        return;
    }
    Retangulo::mousePrecionado(novoMouseEvento);
}

void DTransicao::criaAcoes()
{
    actDeleta = new QAction("Deleta Transicao",this);
    QObject::connect(actDeleta , SIGNAL(triggered()), this, SLOT(deleteta()));
    actExecuta = new QAction("Disparar Transicao",this);
    QObject::connect(actExecuta , SIGNAL(triggered()), this, SLOT(executa()));
    actNovoArco = new QAction("Novo Arco",this);
    QObject::connect(actNovoArco , SIGNAL(triggered()), this, SLOT(novoArco()));
}

void DTransicao::criaMenus()
{
    mnu = new QMenu(widget());
    mnu->addAction(actNovoArco);
    mnu->addAction(actExecuta);
    mnu->addAction(actDeleta);
}

void DTransicao::deleteta()
{
    /*
    QMessageBox msg;
    msg.setText("Funcionalidade ainda nao implementada");
    msg.setInformativeText("Esta funcionalidade ainda nao foi implementa, em breve ela estara funcionando");
    msg.setIcon(QMessageBox::Warning);
    msg.exec();
    */
    delete this;
}

void DTransicao::executa()
{
    m_redePetri->Executa_Transicao(m_id);
}

void DTransicao::novoArco()
{
    DArco *d = new DArco;
    m_pai->novoDesenho(d);
    d->setLigacaoIni(this);
    d->comecaRastriamento();
}

DTransicao::DTransicao():Retangulo(rPonto(10,10), 30 , 10)
{
    inicializaDTransicao();
}

DTransicao::~DTransicao()
{
    if(m_redePetri != 0x0)
    {
        m_redePetri->Exclui_Transicao(m_id);
    }
    m_redePetri = 0x0;
    // O tratamento de desalocamento do desenho é feito
    // no destrutor do desenho.
}

void *DTransicao::getSuper()
{
    return this;
}



void DTransicao::desenha()
{
    if(m_redePetri->Sensibilizado(m_id) )
    {
        setCorFundo(Cor::verde);
    }else
    {
        setCorFundo(Cor(0.0f,0.8f,0.0f));
    }
    Retangulo::desenha();
}

void DTransicao::setNome(QString m_nome)
{
//    Retangulo::setNome( QString("t%1 ").arg(m_id) + m_nome);
    Retangulo::setNome(m_nome);
    /// @todo - Alterar, o nome deve ser salvo apenas no modelo de redes de petri
    m_redePetri->Define_Nome_Transicao(m_id, m_nome.toLocal8Bit().constData());
}

bool DTransicao::setRede(RedePetri *redePetri)
{
    if(redePetri != 0x0)
    {
        if(m_redePetri != 0x0)
        {
            QMessageBox msg;
            msg.setText("Erro, nao pode existir um elemento representando duas redes de petri");
            msg.setInformativeText("Foi atribuido uma nova rede de petri a um elemento que pertencia a uma outra rede de petri, a nova rede nao foi atribuida a esse elemento.");
            msg.setIcon(QMessageBox::Critical);
            msg.exec();
            return false;
        }

        m_redePetri = redePetri;
        m_id = m_redePetri->Nova_Transicao();
        Retangulo::setNome(QString("t%1").arg(m_id));

        return true;
    }

    m_redePetri = 0x0;
}

RedePetri *DTransicao::getRedePetri()
{
    return m_redePetri;
}

unsigned DTransicao::getIDLocal()
{
    return m_id;
}

bool DTransicao::ehTransicao()
{
    return true;
}

bool DTransicao::ehLugar()
{
    return false;
}

bool DTransicao::ehArco()
{
    return false;
}

string &DTransicao::informacao()
{
    return m_redePetri->Informacao_Transicao(m_id);
}


#include "ArestaGrafo.h"

ArestaGrafo::ArestaGrafo(unsigned de, unsigned para, float custo, unsigned id, Grafo *grafo)
{
    m_de = de;
    m_para = para;
    m_custo = custo;
    m_id = id;
    m_grafo = grafo;
}

unsigned ArestaGrafo::de() const
{
    return m_de;
}

unsigned ArestaGrafo::para() const
{
    return m_para;
}

float ArestaGrafo::custo() const
{
    return m_custo;
}

void ArestaGrafo::setCusto(float custo)
{
    m_custo = custo;
}

unsigned ArestaGrafo::id() const
{
    return m_id;
}

Grafo *ArestaGrafo::grafo()
{
    return m_grafo;
}

const Grafo *ArestaGrafo::grafo() const
{
    return m_grafo;
}

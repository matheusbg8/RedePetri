#ifndef CAMBIENTE_H
#define CAMBIENTE_H

#include "DAmbiente.h"
#include "Ambiente.h"
#include "DAmbiente.h"
#include <list>
using namespace std;


/**
 * @brief Esta classe é utilizada para controlar
 * o Ambiente, ela é responsavel por manter a
 * consistencia dos dados entre o modelo classe
 * Ambiente e a visualização classe DAmbiente
 *
 */
class CAmbiente
{
protected:
    // Lista de todas visualizações do ambiente
    list<DAmbiente *> m_visualizacoes;

    // Modelo que esta sendo controlado
    Ambiente *m_modelo;


    void addVariavelVisaualizacao(unsigned idVariavelPai, VariavelAmbiente *novaVariavel);
    void removeVariavelVisualizacao(unsigned id);

    void atualizaVisualizacao(DAmbiente *visualizacao);

public:
    CAmbiente();

    void addVisualizacao(DAmbiente *visualizacao);
    void removeVisualizacao(DAmbiente *visualizacao);
    bool possuiVisualizacoes();

    void setModelo(Ambiente *modelo);

    void addVariavel(unsigned idVariavelPai, VariavelAmbiente *novaVariavel);
    void removeVariavel(unsigned id);

};

#endif // CAMBIENTE_H

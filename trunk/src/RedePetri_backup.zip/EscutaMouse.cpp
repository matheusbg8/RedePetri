#include "EscutaMouse.h"

EscutaMouse::EscutaMouse()
{
}

void EscutaMouse::adiciona()
{
}

void EscutaMouse::remove()
{
}

#ifndef TRIANGULOBASICO_H
#define TRIANGULOBASICO_H

#include "RetanguloBasico.h"

class TrianguloBasico
{
private:
    float mArea; // Area Qudrada
    float mPerimetro;
    float minX, maxX , minY, maxY;
    rPonto mP1;
    rPonto mP2;
    rPonto mP3;

public:
    TrianguloBasico(rPonto p1, rPonto p2, rPonto p3);
    void defineTriangulo(rPonto p1, rPonto p2, rPonto p3);
    bool contemrPonto(rPonto p);
    float area();
    float areaQuadrada();
    float perimetro();
    RetanguloBasico retangulo();
    rPonto p1();
    rPonto p2();
    rPonto p3();
    rPonto centro();

};

#endif // TRIANGULOBASICO_H

#ifndef TIPODESENHO_H
#define TIPODESENHO_H

enum TipoDesenho
{
    TD_INDEFINIDO,
    TD_DESENHO,
    TD_TRIANGULO,
    TD_RETANGULO,
    TD_CIRCULO,
    TD_SEGMENTO,
    TD_POLIGONO,
    TD_SETA,
    TD_TRANSICAO,
    TD_LUGAR,
    TD_ARCO,
    TD_REDE_PETRI,
    TD_GRAFO,
    TD_ARESTA,
    TD_VERTICE
};

#endif // TIPODESENHO_H

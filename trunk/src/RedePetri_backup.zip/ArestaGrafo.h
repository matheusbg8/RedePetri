#ifndef ARESTAGRAFO_H
#define ARESTAGRAFO_H

class Grafo;

class ArestaGrafo
{
protected:
    unsigned m_de;
    unsigned m_para;
    float m_custo;
    unsigned m_id;
    Grafo *m_grafo;

public:
    ArestaGrafo(unsigned de, unsigned para, float custo, unsigned id, Grafo *grafo);

    //virtual ArestaGrafo* copia(Grafo *grafo);

    unsigned de() const;
    unsigned para() const;
    float custo() const;
    void setCusto(float custo);
    unsigned id() const;
    Grafo *grafo();
    const Grafo* grafo() const;
};

#endif // ARESTAGRAFO_H

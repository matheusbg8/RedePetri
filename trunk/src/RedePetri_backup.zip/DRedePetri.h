#ifndef DREDEPETRI_H
#define DREDEPETRI_H


#include "Container.h"
#include "RedePetri.h"
#include "DLugar.h"
#include "DTransicao.h"
#include "DArco.h"


/**
 * @brief
 *  DRedePetri é uma representação gráfica
 * de uma rede de petri.
 *  A idéia foi separar a interface gráfica
 * dos dados e o modelo matematico das Redes
 * de Petri.
 *  A classe DRedePetri possue uma instancia
 * da classe RedePetri, e apenas a manipula
 * dependendo das ações do usuario em sua
 * representação gráfica.
 *  Cada Transição, Lugar e Arco possuem uma
 * representação gráfica chamada DTransicao,
 * DLugar e DArco, também instanciadas
 * dentro da classe DRedePetri, que auxiliam
 * na manipulação do modelo RedePetri.
 *  Por exemplo, todas as ações que o usuario
 * fizer na representação grafica de um DLugar
 * surtira efeito apenas no lugar do modelo
 * RedePetri que o DLugar representa, o mesmo
 * ocorre com DTransicao e DArco.
 */
class DRedePetri : public  QObject, public Container
{
    Q_OBJECT
private:
    static unsigned numRedePetri;
    unsigned m_idRedePetri;

    RedePetri *m_rede;

    QMenu *mnuFundo;

    QAction *novaTransicaoAct;
    QAction *novoLugarAct;
    QAction *novoArcoAct;
    QAction *actGeraXMLSimples;
    QAction *actImprimeRede;
    QAction *actGeraGrafoCobertura;
    QAction *actAlinhar;
    QAction *actDeleta;

    void inicializaDRedePetri();

    list<DLugar*> m_lugares;  /** Lista com todos lugares da rede */
    list<DArco*> m_arcos;  /** Lista com todos arcos */
    list<DTransicao*> m_transicoes; /** Lista com todas transições */

    void criaAcoes();
    void criaMenus();

public:

    DRedePetri(Container *m_pai = 0x0);
    ~DRedePetri();
    void comando(QString cmd);
    void mousePrecionado(MouseEvento *e);

    void *getSuper();

    void removeDesenho(Desenho *d);

    void novoDesenho(Desenho *d, bool avisaFilho = true);

    DLugar * getLugar(unsigned id);
    DTransicao * getTransicao(unsigned id);

    unsigned getNumeroLugar();
    unsigned getNumeroTramsicao();
    unsigned getNumeroArco();

private slots:
    void novaTransicao();
    void novoArco();
    void novoLugar();
    void geraXML();
    void geraXMLSimples();
    void imprimeRede();
    void geraGrafoCobertura();
    void alinhar();
    void deleta();

};

#endif // DREDEPETRI_H

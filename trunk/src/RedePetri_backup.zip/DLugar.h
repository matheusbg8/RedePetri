#ifndef DLUGAR_H
#define DLUGAR_H

#include "CirculoBasico.h"
#include "DComponentePetri.h"
#include "Lugar.h"

/**
 * @brief
 *  Esta classe representa um lugar de uma rede de petri, desenhado na tela,
 * herdando as propriedades do Circulo.
 */
class DLugar : public QObject, public Circulo, public DComponentePetri
{
    Q_OBJECT
public:

    DLugar();
    ~DLugar();
    void *getSuper();

    bool setNumeroFichas(int numFichas);
    int getNumFichas();

    string getInfoFicha(unsigned IDFicha);
    bool setInfoFicha(unsigned IDFicha, string info);

    void desenha();

    void setNome(QString nome);

    // Iterface ComponentePetri
    bool setRede(RedePetri *redePetri);
    RedePetri* getRedePetri();
    unsigned getIDLocal();
    bool ehTransicao();
    bool ehLugar();
    bool ehArco();

protected:
    RedePetri *m_redePetri; /**< Rede Petri que o Lugar esta inserido */
    unsigned m_id;  /**< ID do Lugar na Rede Petri que ele esta inserido */

public slots:
    void novoArco();
    void deleta();
    void adicionaFicha();
    void removeFicha();
private:
    void iniciaDLugar();

    //= Popup menus do Qt ==
    QMenu *mnu;

    QAction *novoArcoAct;
    QAction *deletaAct;
    QAction *actADDFicha;
    QAction *actRMVFicha;
    QAction *actExecuta;
    QAction *actNovoArco;

    void criaAcoes();
    void criaMenus();
    // ===================

    void mousePrecionado(MouseEvento *e);

    friend class DRedePetri;
};

#endif // DLUGAR_H

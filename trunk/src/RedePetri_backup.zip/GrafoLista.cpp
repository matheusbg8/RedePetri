#include "GrafoLista.h"

int GrafoLista::aresta(unsigned deIdVertice, unsigned paraIdVertice) const
{
    if(m_vertices.existeElemento(deIdVertice) && m_vertices.existeElemento(paraIdVertice))
    {
        for(unsigned i = 0; i < m_g[deIdVertice].size() ; i++)
        {
            if(m_g[deIdVertice][i].first == paraIdVertice)
            {
                return m_g[deIdVertice][i].second;
            }
        }
    }
    return -1;
}

GrafoLista::GrafoLista()
{
}

GrafoLista::~GrafoLista()
{
    for(int i = 0, max = m_vertices.maiorIndice() ; i <= max ; i++)
    {
        if(m_vertices.existeElemento(i))
        {
            delete m_vertices[i];
        }
    }

    for(int i = 0, max = m_arestas.maiorIndice() ; i <= max ; i++)
    {
        if(m_arestas.existeElemento(i))
        {
            delete m_arestas[i];
        }
    }
}

Grafo *GrafoLista::novoGrafo() const
{
    return new GrafoLista();
}

unsigned GrafoLista::novoVertice()
{
    VerticeGrafo *nVertice = new VerticeGrafo(m_vertices.proximoID() , this);
    m_vertices.adicionaElemento(nVertice);

    // Se novo vertice esta em uma nova posição
    if(nVertice->id() >= m_g.size())
    {
        m_g.push_back(vector< pair<unsigned , unsigned> >());
        m_invG.push_back(vector< pair<unsigned , unsigned> >());
    }else // Se novo vertice esta em uma posição não utilizada
    {
        m_g[nVertice->id()].clear();
        m_invG[nVertice->id()].clear();
    }
    return nVertice->id();
}

void GrafoLista::criaVertices(unsigned numVertices)
{
    while(numVertices--)
    {
        novoVertice();
    }
}

int GrafoLista::novaAresta(unsigned deIdVertice, unsigned paraIdVertice, float custo)
{
    // Se a aresta é valida
    if(m_vertices.existeElemento(deIdVertice) && m_vertices.existeElemento(paraIdVertice) && aresta(deIdVertice, paraIdVertice) == -1)
    {

        // Cria aresta
        ArestaGrafo *nAresta = new ArestaGrafo(deIdVertice , paraIdVertice , custo , m_arestas.proximoID() , this);

        // Adiciona relacao
        m_g[deIdVertice].push_back(make_pair( paraIdVertice ,  nAresta->id() ));
        m_invG[paraIdVertice].push_back(make_pair( deIdVertice , nAresta->id() ));

        // Adiciona
        m_arestas.adicionaElemento(nAresta);

        return nAresta->id();
    }
    return -1;
}

bool GrafoLista::deletaVertice(unsigned idVertice)
{
    if(m_vertices.existeElemento(idVertice))
    {
        unsigned i , j , u, v, idAresta;
        m_vertices.removeElemento(idVertice);

        // Remove arestas predecesoras do vertice
        for( i = 0 ; i < m_invG[idVertice].size(); i++) // Para todos u predecessores de idVertice
        {
            u = m_invG[idVertice][i].first;

            for(j = 0 ; j < m_g[u].size() ;j++) // Para todos sucessores de u
            {
                // Se o j-esimo sucessor de u for idVertice, exclui aresta
                if(m_g[u][j].first == idVertice)
                {
                    idAresta = m_g[u][j].second;
                    // Apaga aresta
                    m_arestas.removeElemento(idAresta);
                    // Apaga relacao entre os vertices
                    m_g[u].erase(m_g[u].begin() + j);
                    break;
                }
            }
        }
        m_invG[idVertice].clear();

        // Remove arestas sucessoras
        for( i = 0 ; i < m_g[idVertice].size() ; i++) // Para todos v sucessores de idVertice
        {
            v = m_g[idVertice][i].first;
            for(j = 0; j < m_invG[v].size() ; j++)
            {
                // Se o j-esimo predecessor de v é idVertice, apaga aresta
                if(m_invG[v][j].first == idVertice)
                {
                    idAresta = m_invG[v][j].second;
                    // Apaga aresta
                    m_arestas.removeElemento(idAresta);
                    // Apaga relacao entre os vertices
                    m_invG[v].erase(m_invG[v].begin() + j);
                    break;
                }
            }
        }
        m_g[idVertice].clear();

        return true;
    }
    return false;
}

bool GrafoLista::deletaAresta(unsigned idAresta)
{
    if(m_arestas.existeElemento(idAresta))
    {
        unsigned u = m_arestas[idAresta]->de(),
            v = m_arestas[idAresta]->para(),
            i;

        // Apaga relacao do sucessor
        for(i = 0; i < m_g[u].size() ; i++) // Para todos sucessores de u
        {
            if(m_g[u][i].first == v) // Se o i-esimo sucessor de u for v
            {
                // Apaga relacao
                m_g[u].erase( m_g[u].begin() + i);
                break;
            }
        }

        // Apaga relacao do predecessor
        for( i = 0 ; i < m_invG[v].size() ; i++)// Para todos os predecessores de v
        {
            if(m_invG[v][i].first == u) // Se o i-esimo predecessor de v for u
            {
                // apaga relacao
                m_invG[v].erase(m_invG[v].begin() + i);
                break;
            }
        }

        m_arestas.removeElemento(idAresta);
        return true;
    }
    return false;
}

bool GrafoLista::deletaAresta(unsigned de, unsigned para)
{
    int idAresta = aresta(de , para);
    if(idAresta >= 0 )
    {
        return deletaAresta(idAresta);
    }
    return false;
}

bool GrafoLista::setCustoAresta(unsigned idAresta, float custo)
{
    if(m_arestas.existeElemento(idAresta))
    {
        m_arestas[idAresta]->setCusto(custo);
        return true;
    }
    return false;
 }

unsigned GrafoLista::idMaiorVertice() const
{
    return m_vertices.maiorIndice();
}

unsigned GrafoLista::idMaiorAresta() const
{
    return m_arestas.maiorIndice();
}

unsigned GrafoLista::idProximoVertice() const
{
    return m_vertices.proximoID();
}

unsigned GrafoLista::idProximaAresta() const
{
    return m_arestas.proximoID();
}

bool GrafoLista::existeVertice(unsigned idVertice) const
{
    return m_vertices.existeElemento(idVertice);
}

bool GrafoLista::existeAresta(unsigned idAresta) const
{
    return m_arestas.existeElemento(idAresta);
}

bool GrafoLista::existeAresta(unsigned de, unsigned para) const
{
    return aresta(de, para) != -1;
}

unsigned GrafoLista::numVertices() const
{
    return m_vertices.tamanho();
}

unsigned GrafoLista::numArestas() const
{
    return m_arestas.tamanho();
}

int GrafoLista::numPredecessores(unsigned idVertice) const
{
    if(m_vertices.existeElemento(idVertice))
    {
        return m_invG[idVertice].size();
    }
    return -1;
}

int GrafoLista::predecessor(unsigned idVertice, unsigned i) const
{
    if(m_vertices.existeElemento(idVertice))
    {
        return m_invG[idVertice][i].first;
    }
    return -1;
}

float GrafoLista::custoPredecessor(unsigned idVertice, unsigned i) const
{
    if(m_vertices.existeElemento(idVertice))
    {
        return m_arestas[m_invG[idVertice][i].second]->custo();
    }
    return 0.f;
}

int GrafoLista::idArestaPredecessor(unsigned idVertice, unsigned i) const
{
    if(m_vertices.existeElemento(idVertice))
    {
        return m_invG[idVertice][i].second;
    }
    return -1;
}

int GrafoLista::numSucessores(unsigned idVertice) const
{
    if(m_vertices.existeElemento(idVertice))
    {
        return m_g[idVertice].size();
    }
    return -1;
}

int GrafoLista::sucessor(unsigned idVertice, unsigned i) const
{
    if(m_vertices.existeElemento(idVertice))
    {
        return m_g[idVertice][i].first;
    }
    return -1;
}

float GrafoLista::custoSucessor(unsigned idVertice, unsigned i) const
{
    if(m_vertices.existeElemento(idVertice))
    {
        return m_arestas[m_g[idVertice][i].second]->custo();
    }
    return 0.f;
}

int GrafoLista::idArestaSucessor(unsigned idVertice, unsigned i) const
{
    if(m_vertices.existeElemento(idVertice))
    {
        return m_g[idVertice][i].second;
    }
    return -1;
}

list<VerticeGrafo*>::const_iterator GrafoLista::verticeBegin() const
{
    return m_vertices.begin();
}

list<VerticeGrafo*>::const_iterator GrafoLista::verticeEnd() const
{
    return m_vertices.end();
}

list<ArestaGrafo*>::const_iterator GrafoLista::arestaBegin() const
{
    return m_arestas.begin();
}

list<ArestaGrafo*>::const_iterator GrafoLista::arestaEnd() const
{
    return m_arestas.end();
}

const VerticeGrafo *GrafoLista::vertice(unsigned idVertice) const
{
    if(m_vertices.existeElemento(idVertice))
    {
        return m_vertices[idVertice];
    }
    return 0x0;
}

const ArestaGrafo *GrafoLista::aresta(unsigned idAresta) const
{
    if(m_arestas.existeElemento(idAresta))
    {
        return m_arestas[idAresta];
    }
    return 0x0;
}

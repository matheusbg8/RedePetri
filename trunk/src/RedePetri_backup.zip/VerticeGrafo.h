#ifndef VERTICEGRAFO_H
#define VERTICEGRAFO_H

class Grafo;

class VerticeGrafo
{
protected:
    unsigned m_id;
    Grafo *m_grafo;
public:
    VerticeGrafo(unsigned id, Grafo *grafo);

    unsigned id() const;
    Grafo *grafo();
    const Grafo *grafo() const;

};

#endif // VERTICEGRAFO_H

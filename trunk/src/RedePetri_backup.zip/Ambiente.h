#ifndef AMBIENTE_H
#define AMBIENTE_H

#include "VariavelAmbiente.h"
#include "PergutaAmbiente.h"

#include "GerenciadorNomes.h"
#include "GrafoLista.h"

#include <map>
using namespace std;


/**
 * @brief
 *  A classe ambiente representa todos os sensores
 * e atuadores que possam existir em um ambiente,
 * esses sonsores e atuadores são discritos por um
 * conjunto de váriaveis e perguntas.
 *  OBs.: Quando um Ambiente é destruido, todas as
 * variaveis e perguntas referente ao ambiente também
 * são destruidas.
 */

// Uma aresta significa que uma variavel mapeia outra variavel
// Um vertice é uma variavel

class Ambiente: public VariavelAmbiente
{
protected:
    vector<PergutaAmbiente*> m_perguntas;
    vector<VariavelAmbiente*> m_variaveis;

    GrafoLista m_grafo;

    bool registraVariavel(VariavelAmbiente *varivavel);

public:
    Ambiente(string nome);
    virtual ~Ambiente();

    VariavelAmbiente* get(unsigned id);
    VariavelAmbiente* get(string nome);

    bool addPergunta(PergutaAmbiente *novaPergunta);

    bool pergunta(string nomePergunta);
    const PergutaAmbiente *getPergunta(string nomePergunta);

    void imprimeVariaveis();

    const Grafo * grafo() const;

    friend class VariavelAmbiente;
};

#endif // AMBIENTE_H


/*
#include"Ambiente.h"

int main()
{
    Ambiente a("Teste");

    a.addVariavel(new VariavelAmbiente("Y1" , "false"));
    a.addVariavel(new VariavelAmbiente("Y2" , "false"));

    VariavelAmbiente *nova = new VariavelAmbiente("Y1", "compartilhado");

    // Sem Conflito
    a.get("Y1")->addVariavel(new VariavelAmbiente("Y1", "true"));

    // Resolve conflito Y1.Y1 -> Y1.Y1_1
    a.get("Y1")->addVariavel(nova);

    // Conflito Y1.Y1 == Y1.Y1 -> Y1.Y1_1 == Y1.Y1_1 -> Y1.Y1_2
    a.get("Y1")->addVariavel(new VariavelAmbiente("Y1", "true"));

    // Sem conflito
    a.get("Y1")->addVariavel(new VariavelAmbiente("Y1_1_1", "true"));


    // Sem conflito
    a.get("Y2")->addVariavel(new VariavelAmbiente("Y1_1", "true"));

    a.get("Y2")->addVariavel(new VariavelAmbiente("Y1_1_2", "true"));

    // Conflito Y2.Y1_1 (Y2 Y1).Y1_1 -> (Y2 Y1).Y1_1_1 == Y1.Y1_1_1 -> (Y2 Y1).Y1_1_2
    // (Y2 Y1).Y1_1_2 == Y2.Y1_2 -> (Y2 Y1).Y1_1_3
    a.get("Y2")->addVariavel(nova);

    nova->setValor("shared");
    nova->setNome("Machado");

    a.imprimeVariaveis();

    delete nova;

    cout << "Novo ambiente:" <<  endl;

    a.imprimeVariaveis();
}
*/



//#include"Ambiente.h"

//int main()
//{
//    Ambiente a("Teste");

//    a.addVariavel("Matheus.Machado.Dos.Santos", "teste");
//    a.addVariavel("Casa.Bola.Moeda", "ola");
//    a.get("Casa.Bola")->setValor("Olaa222");
//    a.addVariavel("Casa.Dedo", "te");

////    a.addVariavel( new VariavelAmbiente("Matheus", "1"));
////    a.get("Matheus")->addVariavel( new VariavelAmbiente("Machado", "2"));
////    a.get("Matheus.Machado")->addVariavel( new VariavelAmbiente("dos", "3"));
////    a.get("Matheus.Machado.dos")->addVariavel( new VariavelAmbiente("Santos", "4"));

//    a.imprimeVariaveis();
//}

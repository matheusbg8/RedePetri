#include "DArco.h"
#include "DLugar.h"
#include "DTransicao.h"

DArco::DArco()
{
    inicializaDArco();
}

DArco::~DArco()
{
    // O tratamento de desalocamento do desenho é feito
    // no destrutor do desenho.
}

void *DArco::getSuper()
{
    return this;
}

void DArco::setCusto(int custo)
{
    cout << "Definindo novo custo parao arco!" << endl;
    m_custo = custo;
    atualizaCustoEmModDados();
}

int DArco::getCusto()
{
    return m_custo;
}


/**
 * @brief
 *  Retorna o ComponentePetri de origem
 * do arco, ou 0x0 se não existir nenhum
 * componente na origem.
 * @return ComponentePetri - ComponentePetri
 * de origem
 */
DComponentePetri *DArco::getOrigem()
{
    return m_cmpOrigem;
}


/**
 * @brief
 *  Retorna o ComponentePetri de destino
 * do arco, ou 0x0 se não existir nenhum
 * componente conectado.
 * @return ComponentePetri - Componente
 * Petri de desetino.
 */
DComponentePetri *DArco::getDestino()
{
    return m_cmpDestino;
}

void DArco::desenha()
{
    Seta::desenha();

    if(m_custo != 1)
    {
        rPonto posicaoDesenho ( (fim->posicaoLocal() - inicio->posicaoLocal()) /2.f);
        posicaoDesenho += posicaoDesenho.ortoAntiHorario().uni()*10.f + inicio->posicaoLocal();

        desenhaTexto(QString("%1").arg(m_custo), posicaoDesenho, QFont("Times",12,QFont::Bold));
    }
}

bool DArco::setRede(RedePetri *redePetri)
{
    if(redePetri != 0x0)
    {
        if(m_redePetri == 0x0)
        {
            m_redePetri = redePetri;
            return true;
        }

        cout << "Erro ao definir rede petri ao arco, ele já esta em uma rede petri"  << endl;
        return false;
    }
    m_redePetri = 0x0;
}

RedePetri *DArco::getRedePetri()
{
    return m_redePetri;
}

unsigned DArco::getIDLocal()
{
    return m_id;
}

bool DArco::ehTransicao()
{
    return false;
}

bool DArco::ehLugar()
{
    return false;
}

bool DArco::ehArco()
{
    return true;
}

void DArco::inicializaDArco()
{
    setNome(QString("Arco %1").arg(id()));
    m_tipoDesenho = TD_ARCO;
    m_redePetri = 0X0;

    m_cmpOrigem = 0x0;
    m_cmpDestino = 0x0;

    m_custo = 1;

    criaAcoes();
    criaMenus();
}


/**
 * @brief
 *  Tenta pega a ComponentePetri do desenho, se consegui, retorna a referencia
 * pra componente, se não consegui retorna null (0x0).
 * @param desenho - Desenho que possui a componente petri
 * @return ComponentePetri - Componente Petri do desenho
 */
DComponentePetri *DArco::pegaComponente(Desenho *desenho)
{
    DComponentePetri *resp = 0x0;
    if(desenho != 0x0)
    {
        switch(desenho->tipoDesenho())
        {
        case TD_LUGAR:
            resp = (DLugar*) desenho->getSuper();
        break;
        case TD_TRANSICAO:
            resp = (DTransicao*) desenho->getSuper();
        break;
        case TD_ARCO:
            resp = (DArco*) desenho->getSuper();
        break;
        default:
        break;
        }
    }
    return resp;
}


/**
 * @brief
 * Remove a componente petri de origem do arco
 */
void DArco::removeComponenteIni()
{
    if(produzLog)
        cout << "DArco(" << getNome().toStdString() << ")::removeComponenteIni()\n";
    if(m_cmpOrigem != 0x0)
    {
        if(m_redePetri != 0x0 && m_cmpDestino != 0x0)
        {
            if(m_cmpOrigem->ehLugar() && m_cmpDestino->ehTransicao())
            {
                m_redePetri->Remove_Arco_PT(m_cmpOrigem->getIDLocal(), m_cmpDestino->getIDLocal());
            }else if( m_cmpOrigem->ehTransicao() && m_cmpDestino->ehLugar())
            {
                m_redePetri->Remove_Arco_TP(m_cmpOrigem->getIDLocal() , m_cmpDestino->getIDLocal());
            }
        }
        m_cmpOrigem = 0x0;
    }
}

void DArco::removeComponenteFim()
{
    if(produzLog)
        cout << "DArco(" << getNome().toStdString() << ")::removeComponenteFim()\n";

    // Se tem um destino definido
    if(m_cmpDestino != 0x0)
    {
        // Se esta numa rede e possui uma origem (atualiza modelo da rede)
        if(m_redePetri != 0x0 && m_cmpOrigem != 0x0)
        {
            if(m_cmpOrigem->ehLugar() && m_cmpDestino->ehTransicao())
            {
                m_redePetri->Remove_Arco_PT(m_cmpOrigem->getIDLocal(), m_cmpDestino->getIDLocal());
            }else if( m_cmpOrigem->ehTransicao() && m_cmpDestino->ehLugar())
            {
                m_redePetri->Remove_Arco_TP(m_cmpOrigem->getIDLocal() , m_cmpDestino->getIDLocal());
            }
        }
        m_cmpDestino = 0x0;
    }
}


/**
 * @brief
 * Atualiza o custo do arco no modelo de dados
 * para o custo atual m_custo.
 *
 */
void DArco::atualizaCustoEmModDados()
{
    if(m_cmpOrigem != 0x0 && m_cmpDestino != 0x0)
    {
        if(m_redePetri != 0x0)
        {
            if(m_cmpOrigem->ehLugar() && m_cmpDestino->ehTransicao())
            {
                m_redePetri->Novo_Arco_PT(m_cmpOrigem->getIDLocal(),m_cmpDestino->getIDLocal(), m_custo);
                cout << "Atualizado peso do arco PT" << endl;
            }
            else if( m_cmpOrigem->ehTransicao() && m_cmpDestino->ehLugar())
            {
                m_redePetri->Novo_Arco_TP(m_cmpOrigem->getIDLocal(),m_cmpDestino->getIDLocal(), m_custo);
                cout << "Atualizado peso do arco TP" << endl;
            }
            else
                cout << "Erro ao atualizar custo do arco, componentes invalidos" << endl;
        }else
            cout << "Erro ao atualizar custo do arco, sem modelo de dados" << endl;
    }else
    {
        cout << "Arco não possui duas ligações" << endl;
    }
}

void DArco::mousePrecionado(MouseEvento *novoMouseEvento)
{
    if(novoMouseEvento->botao() == BOTAO_DIREITO)
    {
        mnu->exec(novoMouseEvento->posicaoJanela());
        return;
    }
    Seta::mousePrecionado(novoMouseEvento);
}

void DArco::criaAcoes()
{
    actDeleta = new QAction("Deleta Arco",this);
    QObject::connect(actDeleta, SIGNAL(triggered()), this, SLOT(deleta()));
}

void DArco::criaMenus()
{
    mnu = new QMenu(widget());
    mnu->addAction(actDeleta);
}

bool DArco::aceitaLigacaoIni(Desenho *desenho)
{
    /** @todo - Acho que é melhor sobrescreve o metodo setLigacaoIni,
      * e não aceitaLigacaoIni.
     **/

    // Se for para remover o componente
    if(desenho == 0x0)
    {
        removeComponenteIni();
        return true;
    }

    DComponentePetri *novaComponente = pegaComponente(desenho);

    // Se possuei uma rede de petri
    if(m_redePetri != 0x0 && novaComponente != 0x0)
    {
        // Se tem componente de destino
        if(m_cmpDestino != 0x0)
        {
            if(novaComponente->ehLugar() && m_cmpDestino->ehTransicao())
            {
                m_cmpOrigem = novaComponente;
                m_redePetri->Novo_Arco_PT(m_cmpOrigem->getIDLocal(), m_cmpDestino->getIDLocal(), m_custo);
                return true; // Aceita a ligação
            }else if(novaComponente->ehTransicao() && m_cmpDestino->ehLugar())
            {
                m_cmpOrigem = novaComponente;
                m_redePetri->Novo_Arco_TP(m_cmpOrigem->getIDLocal() , m_cmpDestino->getIDLocal(), m_custo);
                return true; // Aceita a ligação
            }else
            {
                cout << "Erro ao definir arco, não é permitido ligações de transição com transição ou lugar com lugar" << endl;
                QMessageBox msgErro;
                msgErro.setText("Nao e permitido ligacao de lugar com lugar ou transicao com transicao");                
                msgErro.exec();
            }
        }else // Primero componente que esta sendo ligado
        {
            m_cmpOrigem = novaComponente;
            return true;
        }
    }
    else{
        cout << "Erro ao definir arco, o arco não possui uma rede de petri associada" << endl;
        QMessageBox msgErro;
        msgErro.setText("Erro ao definir arco, o arco não possui uma rede de petri associada");
        msgErro.exec();
    }
    return false; // Não aceita a ligação
}

bool DArco::aceitaLigacaoFim(Desenho *desenho)
{
    //Se for para remover uma ligação
    if(desenho == 0x0)
    {
        removeComponenteFim();
        return true;
    }

    DComponentePetri *novaComponente = pegaComponente(desenho);

    // Se possuei uma rede de petri
    if(m_redePetri != 0x0 && novaComponente != 0x0)
    {
        // Se tem componente de origem
        if(m_cmpOrigem != 0x0)
        {
            if(m_cmpOrigem->ehLugar() && novaComponente->ehTransicao())
            {
                m_cmpDestino = novaComponente;
                m_redePetri->Novo_Arco_PT(m_cmpOrigem->getIDLocal(), m_cmpDestino->getIDLocal(), m_custo);
                return true; // Aceita a ligação
            }else if(m_cmpOrigem->ehTransicao() && novaComponente->ehLugar())
            {
                m_cmpDestino = novaComponente;
                m_redePetri->Novo_Arco_TP(m_cmpOrigem->getIDLocal() , m_cmpDestino->getIDLocal(), m_custo);
                return true; // Aceita a ligação
            }else
            {
                cout << "Erro ao definir arco, não é permitido ligações de transição com transição ou lugar com lugar" << endl;
                QMessageBox msgErro;
                msgErro.setText("Nao e permitido ligacao de lugar com lugar ou transicao com transicao");
                msgErro.exec();
            }
        }else // Primero componente que esta sendo ligado
        {
            m_cmpDestino = novaComponente;
            return true;
        }
    }
    else{
        cout << "Erro ao definir arco, o arco não possui uma rede de petri associada ou o novo componente petri associado ao arco é inválido" << endl;
        QMessageBox msgErro;
        msgErro.setText("Erro ao definir arco, o arco não possui uma rede de petri associada ou o novo componente petri associado ao arco é inválido");
    }
    return false; // Não aceita a ligação
}

/**
 * @brief
 *  Slot que exclui o arco
 */
void DArco::deleta()
{
    delete this;
}


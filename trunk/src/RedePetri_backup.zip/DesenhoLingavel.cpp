#include "DesenhoLingavel.h"

DesenhoLingavel::DesenhoLingavel()
{
}

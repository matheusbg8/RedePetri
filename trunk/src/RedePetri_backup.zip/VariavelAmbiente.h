#ifndef VARIAVELAMBIENTE_H
#define VARIAVELAMBIENTE_H

#include "GerenciadorNomes.h"
#include <string>
#include <iostream>
#include "Grafo.h"
using namespace std;

// Ambiente inclui VariavelAmbiente.h
class Ambiente;

/**
 * @brief
 *  Esta classe é utilizada para armazenar uma
 * variavel do ambiente, ela pode ser composta
 * por outras variaveis.
 * Obs.: Quando uma variavel é detruida, todas
 * as variaveis que a compoem também são destruidas
 * e as referencias dos pais para averiavel é eliminada
 */
class VariavelAmbiente
{
protected:
    string m_nome;
    string m_valor;

    Ambiente *m_ambiente;

    bool executandoDestrutor;

    unsigned m_id;

    // Nao pode ser utilizado Gerenciador de Nomes
    // aqui devido aos buracos, os IDs sao gerados
    // no ambiente e sao unicos para todas variaveis
    // existentes
    map<string, unsigned> m_mapaVariaveis;

    string encontraNomeDisponivel(const string & nome);

    string registraMapeamento(const string & nome, unsigned id);
    VariavelAmbiente* getDireto(const string &nomeVariavel);

    // Este metodo é chamado apenas pelas outras variaveisAmbiente
    string renomeiaVariavel(VariavelAmbiente* variavel , const string &novoNome);
public:

    VariavelAmbiente(string nome, string valor);
    virtual ~VariavelAmbiente();

    VariavelAmbiente* get(string nome);

    bool possuiAmbiente() const;

    bool addVariavel(VariavelAmbiente *novaVariavel);
    bool addVariavel(string nome, string valor);

    bool removeVariavel(VariavelAmbiente *variavel);
    bool removeVariavel(const string &nomeVariavel);

    const string& nome() const;
    const string& valor() const;

    void setValor(string valor);
    virtual const string &setNome(string nome);

    unsigned id() const;

    friend class Ambiente; // Utilizado para definir o ambiente de forma privada
};

#endif // VARIAVELAMBIENTE_H

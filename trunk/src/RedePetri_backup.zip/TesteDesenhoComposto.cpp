#include "TesteDesenhoComposto.h"

TesteDesenhoComposto::TesteDesenhoComposto()
{
    circCimaDireita = new Circulo(5, rPonto(50,50));
    circCimaEsquerda = new Circulo(5, rPonto(20,50));
    circBaixoDireita = new Circulo(5, rPonto(50,20));
    circBaixoEsquerda  = new Circulo(5, rPonto(20,20));

    novaComposicao(circCimaDireita);
    novaComposicao(circCimaEsquerda);
    novaComposicao(circBaixoDireita);
    novaComposicao(circBaixoEsquerda);
}

void TesteDesenhoComposto::mousePrecionadoComposto(Desenho *desenho, MouseEvento *mouseEvento)
{
    if(desenho == circCimaDireita)
    {
        mousePrecionado(mouseEvento);
    }
}

void TesteDesenhoComposto::mouseSoltoComposto(Desenho *desenho, MouseEvento *mouseEvento)
{
    if(desenho == circCimaDireita)
    {
        mouseSolto(mouseEvento);
    }else if(desenho == circBaixoDireita)
    {
        circCimaDireita->setCorFundo(Cor::verde);
    }else if(desenho == circBaixoEsquerda)
    {
        circCimaDireita->setCorFundo(Cor::vermelho);
    }else if(desenho == circCimaEsquerda)
    {
        if(circCimaDireita->visivel())
        {
            circCimaDireita->setVisivel(false);
        }else
        {
            circCimaDireita->setVisivel(true);
        }
    }
}

void TesteDesenhoComposto::mouseMovendoComposto(Desenho *desenho, MouseEvento *mouseEvento)
{
    if(desenho == circCimaDireita)
    {
        mouseMovendo(mouseEvento);
    }
}

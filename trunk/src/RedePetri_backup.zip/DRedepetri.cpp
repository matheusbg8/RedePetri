#include "DRedePetri.h"
#include <iostream>
#include <QMessageBox>
#include <QDomNode>
#include "DLugar.h"
#include "DTransicao.h"
#include "DArco.h"
#include <QtGui>
#include <qobject.h>
#include <cstdio>
#include "DGrafo.h"
#include "VisualizadorGrafo.h"

unsigned DRedePetri::numRedePetri = 0;

void DRedePetri::inicializaDRedePetri()
{
    cout << "Iniciando nova rede de petri" << endl;
    m_rede = new RedePetri(1,1);
    m_tipoDesenho = TD_REDE_PETRI;

    numRedePetri++;
    m_idRedePetri = numRedePetri;

    criaAcoes();
    criaMenus();
    setNome(QString("Rede Petri %1").arg(m_idRedePetri));
}

void DRedePetri::criaAcoes()
{
    novaTransicaoAct = new QAction("Nova Transicao" , this);
    QObject::connect(novaTransicaoAct, SIGNAL(triggered()), this, SLOT(novaTransicao()));

    novoLugarAct = new QAction("Novo Lugar" , this);
    QObject::connect(novoLugarAct, SIGNAL(triggered()), this, SLOT(novoLugar()));

    novoArcoAct = new QAction("Novo Arco" ,this);
    QObject::connect(novoArcoAct, SIGNAL(triggered()), this, SLOT(novoArco()));

    actGeraXMLSimples = new QAction("Gera XML Simples", this);
    QObject::connect(actGeraXMLSimples, SIGNAL(triggered()),this,SLOT(geraXMLSimples()));

    actImprimeRede = new QAction("Imprime Rede", this);
    QObject::connect(actImprimeRede, SIGNAL(triggered()),this,SLOT(imprimeRede()));

    actGeraGrafoCobertura = new QAction("Gera Grafo de Cobertura", this);
    QObject::connect(actGeraGrafoCobertura, SIGNAL(triggered()),this, SLOT(geraGrafoCobertura()));

    actAlinhar = new QAction("Alinhar", this);
    QObject::connect(actAlinhar, SIGNAL(triggered()),this, SLOT(alinhar()));

    actDeleta = new QAction("Deleta", this);
    QObject::connect(actDeleta, SIGNAL(triggered()),this, SLOT(deleta()));

}

void DRedePetri::criaMenus()
{
    mnuFundo = new QMenu(widget());
    mnuFundo->addAction(novaTransicaoAct);
    mnuFundo->addAction(novoLugarAct);
    mnuFundo->addAction(novoArcoAct);
    mnuFundo->addAction(actGeraXMLSimples);
    mnuFundo->addAction(actImprimeRede);
    mnuFundo->addAction(actGeraGrafoCobertura);
    mnuFundo->addAction(actAlinhar);
    mnuFundo->addAction(actDeleta);
}


DRedePetri::DRedePetri(Container *pai):Container(rPonto(30,30),100,100,pai)
{
    inicializaDRedePetri();
}

DRedePetri::~DRedePetri()
{
/**
  @todo - Problema do destrutor da rede petri grafica,
  esse problema foi resolvido, mas esse todo continua
  para que todos estejam sabendo de sua existencia e
  para que encontre futuramente uma solução melhor que a
  utilizada.
**/
    /*
        Aqui ocorre um problema na desalocação da rede grafica(DRedePetri)
    todos os componentes graficos da rede (DLugar , DTranscao e DArco)
    possuem referencia ao modelo de dados da rede petri (RedePetri) que
    esta sendo deletado logo a baixo por esse destrutor.
        O problema ocorre porque o destrutor da DRedePetri é chamado
    primeiro que o destrutor do Container, isso faz com que o modelo
    de dados seja deletado antes dos componentes graficos. Logo apos
    o modelo de dados da rede ser deletado por esse destrutor, o
    destrutor do container deleta todos os seus desenhos. Quando
    uma transição, ligada a um arco com um lugar, é deletada,
    um evento (deletando) é gerado para o arco, fazendo com que ele
    remova o arco do modelo de dados, porem o modelo de dados não existe
    mais porque foi deletado aqui, ocorre então uma falha de segmentação.
        Solução, antes de deletar o modelo de dados, é redefinido
    o modelo de todos componentes como 0x0, assim os componentes
    não vão tentar alterar o modelo já desalocado.
    */

    for(list<DLugar*>::iterator i = m_lugares.begin() ; i != m_lugares.end() ; i++)
    {
        (*i)->setRede(0x0);
    }
    for(list<DTransicao*>::iterator i = m_transicoes.begin(); i != m_transicoes.end() ; i++)
    {
        (*i)->setRede(0x0);
    }
    for(list<DArco*>::iterator i = m_arcos.begin() ; i != m_arcos.end() ; i++)
    {
        (*i)->setRede(0x0);
    }
    delete m_rede;
}

void DRedePetri::comando(QString cmd)
{
    QStringList cmdList = cmd.split(" ", QString::SkipEmptyParts);

    if(cmdList.at(0) == "novo")
    {
        if(cmdList.at(1) == "lugar")
        {
            cout << "Solicitação para criar novo lugar" << endl;
        }else if( cmdList.at(1) == "transicao")
        {
            cout << "Solicitacao de nova transicao" << endl;
        }
    }else
    {
        cout << "Comando não reconhecido" << endl;
    }
}

void DRedePetri::mousePrecionado(MouseEvento *e)
{
    if(e->botao() == BOTAO_DIREITO )
    {
        if(produzLog)
            cout << "Posicao " << e->posicaoJanela().x() << " , " << e->posicaoJanela().y() << endl;
        mnuFundo->exec(e->posicaoJanela());
        if(produzLog)
            cout << "Clicado na rede de petri" << endl;
    }else
    {
        Container::mousePrecionado(e);
    }
}

void *DRedePetri::getSuper()
{
    return this;
}


/**
 * @brief
 *  Sobrescreve o metodo remove desenho adicionando uma funcionalidade
 * de remover o a referencia da rede aos desenho, após esta operação
 * é chamado o removeDesenho do Container.
 * @param d
 */
void DRedePetri::removeDesenho(Desenho *d)
{
    switch(d->tipoDesenho())
    {
        case TD_LUGAR:
            m_lugares.remove((DLugar*)  d);
        break;

        case TD_TRANSICAO:
            m_transicoes.remove((DTransicao*) d);
        break;
        case TD_ARCO:
            m_arcos.remove((DArco*) d);
        break;
        default:
        break;

    }
    Container::removeDesenho(d);
}

/**
 * @brief
 *  Esse metodo chama o novo desenho da classe inferior Container,
 * somente se o desenho for do tipo TD_LUGAR, TD_TRANSICAO ou
 * TD_ARCO, caso contrario o novo desenho será deletado.
 * Pois este desenho não pode ser aceito.
 * @param d - Novo desenho que será adicionado.
 */
void DRedePetri::novoDesenho(Desenho *d, bool avisaFilho)
{

    TipoDesenho tipo = d->tipoDesenho();
    if(tipo == TD_LUGAR)
    {
        DLugar *lugar = (DLugar*) d->getSuper();
        lugar->setRede(m_rede);

        m_lugares.push_back(lugar);

        Container::novoDesenho(d, avisaFilho);
    }else
    if(tipo == TD_TRANSICAO)
    {
        DTransicao *transicao = (DTransicao*) d->getSuper();
        transicao->setRede(m_rede);

        m_transicoes.push_back(transicao);
        Container::novoDesenho(d, avisaFilho);
    }else
    if(tipo == TD_ARCO)
    {
        DArco *arco = (DArco*) d->getSuper();
        arco->setRede(m_rede);

        m_arcos.push_back(arco);
        Container::novoDesenho(d, avisaFilho);
    }else
    {
        QMessageBox msg;
        msg.setText("Adicao de componente nao permitido");
        msg.setInformativeText("Adicao de um elemento nao pertencente a classe de elementos da Rede de Petri");
        msg.setIcon(QMessageBox::Warning);
        msg.exec();
        cout << "Adicionando elemento inválido a rede de petri" << endl;
        delete d;
    }
}


/**
 * @brief
 *  Retorna o lugar com id especifico que
 * esta dentro da rede, ou 0x0 se não existir
 * esse lugar.
 * @param id - id do lugar que sera retornado
 * @return DLugar - lugar com o id especifico
 */
DLugar *DRedePetri::getLugar(unsigned id)
{
    list<DLugar*>::iterator i;
    for( i = m_lugares.begin() ; i != m_lugares.end() ; i++)
    {
        if((*i)->getIDLocal() == id)
            return (*i);
    }
    return 0x0;
}

/**
 * @brief
 *  Retorna a transicao com id especifico que
 * esta dentro da rede, ou 0x0 se não existir
 * essa transição.
 * @param id - id da transicão que sera retornada
 * @return DTransicao - transição com o id especifico.
 */
DTransicao *DRedePetri::getTransicao(unsigned id)
{
    list<DTransicao*>::iterator i;
    for( i = m_transicoes.begin() ; i != m_transicoes.end() ; i++)
    {
        if((*i)->getIDLocal() == id)
            return (*i);
    }
    return 0x0;
}

unsigned DRedePetri::getNumeroLugar()
{
    if(m_rede != 0x0)
    {
        return m_rede->Numero_Lugares();
    }
}

unsigned DRedePetri::getNumeroTramsicao()
{
    if(m_rede != 0x0)
    {
        return m_rede->Numero_Transicoes();
    }
}

unsigned DRedePetri::getNumeroArco()
{
    if(m_rede != 0x0)
    {
        return m_rede->Numero_Arcos();
    }
}

void DRedePetri::novaTransicao()
{
    Desenho *d = new DTransicao;
    d->setNomeVisivel(true);
    novoDesenho(d);
//    m_desenhoMestre->redesenha();
}

void DRedePetri::novoArco()
{
    Seta *d = new DArco;
    d->defineSeta(rPonto(20,20) , rPonto(80,50));
    novoDesenho(d);
//    m_desenhoMestre->redesenha();
}

void DRedePetri::novoLugar()
{
    Desenho *d = new DLugar;
    d->setNomeVisivel(true);
    novoDesenho(d);
//    m_desenhoMestre->redesenha();
}

void DRedePetri::geraXML()
{
    FILE *teste;
    teste = fopen("teste.xml", "w+");

    cout << "======== Teste XML ========" << endl;
    QDomDocument d;

    QFile xml("books.xml");
    if(xml.open(QIODevice::ReadWrite))
    {
        d.setContent(&xml);
        QDomNode n = d.firstChild();
        while (!n.isNull())
        {
            if (n.isElement())
            {
                QDomElement e = n.toElement();
                cout << "Element name: " << e.tagName().toStdString()
                     << ',' << e.attribute("category").toStdString() << endl;

                QDomElement novoE = d.createElement("Aleatorio");
                novoE.setAttribute("Teste" , "HAHAHA");


                QDomText txt = d.createTextNode("Texto de Teste!!!");
                novoE.appendChild(txt);

                e.appendChild(novoE);

                if(e.tagName() == "bookstore")
                {   cout << "BINGO!!" << endl;
                    n = n.firstChild();
                    continue;
                }

                if(e.attribute("category") == "web")
                {
                    e.setAttribute("Web", "www");
                    n = e.firstChild();
                    continue;
                }
                if(e.tagName() == "year")
                {
                    n = e.firstChild();
                    if(n.isText())
                    {
                        QDomText txt = d.createTextNode("texto ano");
                        e.appendChild(txt);
                    }
                }
            }
            if(n.isAttr())
            {
                QDomAttr a = n.toAttr();
                cout << "Attribut name: " << a.name().toStdString()
                     << " value: " << a.value().toStdString() << endl;
            }
            if(n.isCDATASection())
            {
                cout << '1' << endl;
            }
            if(n.isCharacterData())
                cout << '2' << endl;
            if(n.isComment())
                cout << '3' << endl;
            if(n.isDocument())
                cout << '4' << endl;
            if(n.isElement())
                cout << '5' << endl;
            if(n.isEntity())
                cout << '7' << endl;
            if(n.isNotation())
                cout << '7' << endl;
            if(n.isText())
                cout << '8' << endl;
            if(n.isProcessingInstruction())
                cout << '9' << endl;

//            n = n.firstChild();

            n = n.nextSibling();
        }
        QTextStream f(teste);
        d.save(f,5);
    }else cout << "Erro ao abrir xml\n";

    fclose(teste);
    cout << "======== Teste XML FIM=====" << endl;
}

void DRedePetri::geraXMLSimples()
{
    FILE *arq;
    QString nomeArquivo = QFileDialog::getSaveFileName(widget(), "Salvar XML", QString(),"XML (*.xml)");
    arq = fopen((nomeArquivo.toStdString().c_str()), "w+");

    if(arq != 0x0)
    {
        QDomDocument d;
        QDomNode raiz, n;

        QDomElement e = d.createElement("RedePetri");
        e.setAttribute("Nome" , m_nome);

        n = raiz = d.appendChild(e);

        QDomAttr atr;

        // Lugares
        list<DLugar*>::iterator il;
        for(il = m_lugares.begin() ; il != m_lugares.end(); il++)
        {
            e = d.createElement("Lugar");
            e.setAttribute("Nome", (*il)->getNome());
            e.setAttribute("Fichas", (*il)->getNumFichas());
            e.setAttribute("X", (*il)->getCentro().x());
            e.setAttribute("Y", (*il)->getCentro().y());
            raiz.appendChild(e);
        }

        // Transições
        list<DTransicao*>::iterator it;
        for(it = m_transicoes.begin() ; it != m_transicoes.end(); it++)
        {
            e = d.createElement("Transicao");
            e.setAttribute("Nome", (*it)->getNome());
            e.setAttribute("X", (*it)->x());
            e.setAttribute("Y", (*it)->y());
            raiz.appendChild(e);
        }

        // Arcos
        list<DArco*>::iterator ia;
        DComponentePetri *origem, *destino;
        for(ia = m_arcos.begin() ; ia != m_arcos.end(); ia++)
        {
            origem = (*ia)->getOrigem(); destino = (*ia)->getDestino();
            if( origem != 0x0 && destino != 0x0)
            {
                e = d.createElement("Arco");
                e.setAttribute("Nome", (*ia)->getNome());
                e.setAttribute("Custo", (*ia)->getCusto());
                if(origem->ehLugar() && destino->ehTransicao())
                {
                    e.setAttribute("De", QString("p%1").arg(origem->getIDLocal()));
                    e.setAttribute("Para", QString("t%1").arg(destino->getIDLocal()));
                }else if(origem->ehTransicao() && destino->ehLugar())
                {
                    e.setAttribute("De", QString("t%1").arg(origem->getIDLocal()));
                    e.setAttribute("Para", QString("p%1").arg(destino->getIDLocal()));
                }
                raiz.appendChild(e);
            }
        }


        QTextStream Qs(arq);
        d.save(Qs,4);
        fclose(arq);
    }else cout << "Problema ao abrir xml" << endl;

}

void DRedePetri::imprimeRede()
{
    m_rede->imprime_incidencia();
    m_rede->imprime_pos();
    m_rede->imprime_pre();
    m_rede->imprime_marcacao();

}

void DRedePetri::geraGrafoCobertura()
{
    if(m_pai != 0x0 && m_rede != 0x0)
    {
        VisualizadorGrafo *grafo = new VisualizadorGrafo;
        m_pai->novoDesenho(grafo);
        GrafoNome *modeloGrafo = new GrafoNome(string("Grafo de Cobertura"));

        m_rede->Enumera((*modeloGrafo));
        grafo->setModelo(modeloGrafo);
    }

/*    if(m_pai != 0x0)
    {
        Grafo<char> *grafo = new Grafo < char >;
        grafo->novoVertice('a');
        grafo->novoVertice('b');
        grafo->novoVertice('c');
        grafo->novoVertice('d');
        grafo->novoVertice('e');
        grafo->novoVertice('f');
        grafo->novoVertice('g');
        grafo->novoVertice('h');
        grafo->novoVertice('i');
        grafo->novoVertice('j');

        grafo->novaAresta('a', 'b');
        grafo->novaAresta('c','a');
        grafo->novaAresta('d','a');
        grafo->novaAresta('e','a');
        grafo->novaAresta('f','a');
        grafo->novaAresta('g','a');
        grafo->novaAresta('h','a');
        grafo->novaAresta('i','a');
        grafo->novaAresta('j','a');

        DGrafo *vgrafo = new DGrafo;
        m_pai->novoDesenho(vgrafo);
        vgrafo->setModelo(grafo);
    }
*/
}

void DRedePetri::alinhar()
{
    Container::alinhar();
}

void DRedePetri::deleta()
{
    delete this;
}




#include "GrafoMatriz.h"

GrafoMatriz::GrafoMatriz():
    matriz(1,1)
{

}

#include "RedePetri.h"

#include "Arco.h"

Arco::Arco(RedePetri *redePetri)
{
    m_custo = 1;
}

bool Arco::setLigacao(DComponentePetri *de, DComponentePetri *para)
{
    if(de->ehLugar() && para->ehTransicao())
    {
        m_redePetri->Novo_Arco_PT(de->getIDLocal(), para->getIDLocal(), m_custo);
        return true;
    }
    return false;
}

bool Arco::setCusto(int val)
{
    m_custo = val;
    return true;
}

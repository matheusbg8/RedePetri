#include "CAmbiente.h"


/**
 * @brief
 *  Avisa todas visualizações que uma novavariavel foi adicionada
 * ao modelo
 * @param idPai - ID do pai da variavel
 * @param novaVar - Variavel que foi adicionada
 */
void CAmbiente::addVariavelVisaualizacao(unsigned idVariavelPai, VariavelAmbiente *novaVariavel)
{
    // Atualiza Visualizacoes
    list<DAmbiente*>::iterator li;
    for(li = m_visualizacoes.begin() ; li != m_visualizacoes.end() ; li++)
    {
        (*li)->addVariavel(idVariavelPai , novaVariavel);
    }
}

void CAmbiente::removeVariavelVisualizacao(unsigned id)
{
    // Atualiza visualizacoes
    list<DAmbiente*>::iterator li;
    for(li = m_visualizacoes.begin() ; li != m_visualizacoes.end() ; li++)
    {
        (*li)->removeVariavel(id);
    }
}


/**
 * @brief
 *  Atualiza a visualização informa o modelo atual
 * @param visualizacao- Visualização que sera atualizada
 */
void CAmbiente::atualizaVisualizacao(DAmbiente *visualizacao)
{
    const Grafo * grafo = m_modelo->grafo();
    unsigned de, para;

    visualizacao->apagaTudo();
    visualizacao->setNome(QString(m_modelo->nome().c_str()));

    list<ArestaGrafo*>::const_iterator la;
    for(la = grafo->arestaBegin(); la != grafo->arestaEnd() ; la++)
    {
        de = (*la)->de();
        para = (*la)->para();
        visualizacao->addVariavel(de, m_modelo->get(para));
    }
}

CAmbiente::CAmbiente()
{

}

void CAmbiente::addVisualizacao(DAmbiente *visualizacao)
{
    m_visualizacoes.push_back(visualizacao);

    // Se ja possui modelo
    if(m_modelo != 0x0)
        atualizaVisualizacao(visualizacao);
}

void CAmbiente::removeVisualizacao(DAmbiente *visualizacao)
{
    m_visualizacoes.remove(visualizacao);
}

bool CAmbiente::possuiVisualizacoes()
{
    return !m_visualizacoes.empty();
}

void CAmbiente::setModelo(Ambiente *modelo)
{
    if(modelo == 0x0)
        return;

    m_modelo = modelo;

    // Atualiza todas visualizações
    list<DAmbiente*>::iterator lda;
    for(lda = m_visualizacoes.begin() ; lda != m_visualizacoes.end() ; lda++)
    {
        atualizaVisualizacao(*lda);
    }

}

void CAmbiente::addVariavel(unsigned idVariavelPai, VariavelAmbiente *novaVariavel)
{
    VariavelAmbiente * vpai = m_modelo->get(idVariavelPai);

    // Atualiza modelo
    if(vpai != 0x0)
    {
        vpai->addVariavel(novaVariavel);
    }

    addVariavelVisaualizacao(idVariavelPai , novaVariavel);
}


/**
 * @brief
 *  Remove variavel do ambiente
 * @param id - ID da variavel que sera removida
 */
void CAmbiente::removeVariavel(unsigned id)
{
    /// @todo - Corrigir problema de remover variavel, dependencia pai->filho
    // Atualiza Modelo
    m_modelo->removeVariavel(m_modelo->get(id));

    removeVariavelVisualizacao(id);
}

//#include"RedePetri.h"

#ifndef CONTROLE_H
#define CONTROLE_H

class Controle
{
protected:
//    RedePetri *rede;

public:

    void comando(char *cmd);

    Controle();
};

#endif // CONTROLE_H
